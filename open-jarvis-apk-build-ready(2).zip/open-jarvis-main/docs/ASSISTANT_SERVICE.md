# Jarvis Ön Plan Servisi ve Türkçe Uyku Sözcüğü Dinlemesi (Issue #7)

## Ne yapar?

- **Açık başlatma/durdurma:** Jarvis artık panelden (dashboard) tek dokunuşla
  başlatılıp durduruluyor. Durum kartı servisin gerçek durumunu Türkçe gösterir
  (kapalı / başlatılıyor / dinliyor / komut bekliyor / çalıştırılıyor / duraklatıldı / hata).
- **Kalıcı bildirim:** Servis ön planda çalışırken "Sürekli dinleme açık.
  Söyleyin: \"Jarvis\" + komutunuz." bildirimi görünür ve **Durdur** eylemi içerir.
- **Türkçe uyku sözcüğü:** `SpeechRecognizer` (tr-TR) döngüsel çalıştırılır;
  "Jarvis" (yayın tanıma hatalarına karşı ±1 harf toleransı, örn. "jervis")
  algılandığında sonraki konuşma komut olarak `AgentCore.executeTask`'a gider.
  Uyku sözcüğü tek başına söylenirse servis komutu bekler ("Komutunuzu söyleyin").
- **Pil bilinci:** Sürekli dinleme pil kullanır. Pil zayıfken (varsayılan %15 altı)
  ve cihaz şarjda değilken servis **duraklar** ve kullanıcıya Türkçe neden bildirir.
  "Her zaman açık" iddiası YOKTUR.
- **Dürüst hata yönetimi:** Mikrofon izni yok, konuşma tanıma hizmeti yok veya
  başlatma başarısız olursa servis kendini durdurur ve hatayı gösterir — uygulama
  asla çökmez.

## Kullanım

1. Panelden **"Jarvis'ı başlat"** düğmesine dokunun (mikrofon izni istenir).
2. Bildirim çubuğunda Jarvis'in dinlediğini görürsünüz.
3. "Jarvis" + komutunuzu söyleyin (örneğin: "Jarvis, Sıla'ya SMS gönder").
4. Durdurmak için: paneldeki **"Jarvis'ı durdur"** veya bildirimdeki **Durdur**.

## TECNO Spark 20 Pro / HiOS pil kısıtları (kullanıcıya not)

HiOS, arka plan işlemlerini agresif kesebilir. Sorunsuz çalışma için:

1. Ayarlar → Pil → Jarvis/Open Jarvis → **Kısıtlanmamış / Arka planda çalışmaya izin ver**.
2. Ayarlar → Uygulamalar → Open Jarvis → Pil → **Pil optimizasyonunu yoksay**.
3. Son uygulamalar ekranında Jarvis kartını kilitleyin (HiOS "kilit" özelliği).
4. Bildirim izni verilmiş olmalı (Android 13'te kurulumda istenir); bildirim izni
   reddedilirse servis yine çalışır ama kalıcı durum bildirimi görünmez.
5. Kapalıyken bile pil öldürme yapıyorsa servis sistemi tarafından durdurulabilir;
   bu durumda panelden yeniden başlatmanız gerekir. Bu, Android'in değil HiOS'un
   davranışıdır ve uygulama tarafından aşılamaz.

## Teknik sınırlamalar

- Dinleme, `SpeechRecognizer`'ın döngüsel yeniden başlatılması ile yapılır; bu,
  cihazda sıcak sözcük (hotword) motoru olmadığı için bilinen, doğru yaklaşım ve
  bir miktar pil harcar. Donanım seviyesinde "her zaman açık" hotword bu sürümde yoktur.
- Ses tanıma hizmeti, cihazdaki Google uygulaması/tanıma servisine bağlıdır.
- Komut yürütmesi, sesli komut ekranındaki ile aynı `AgentCore` hattını kullanır;
  SMS/görüşme gibi hassas işlemler issue #5'teki onay akışından geçer.
- Emülatörde (API 33) doğrulandı: servis durum geçişleri, izin yok/hata yolları
  ve durdurma; fiziksel TECNO cihaz doğrulaması kurulum sonrası kullanıcıya aittir.
