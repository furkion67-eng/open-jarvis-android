package com.openjarvis.bridge

import org.json.JSONObject

/**
 * Pure wire-protocol helpers for the local bridge socket.
 *
 * Extracted from SocketServer so the protocol contract can be unit-tested
 * on the JVM without any Android runtime dependency.
 */
object SocketProtocol {

    internal const val MAX_COMMAND_LENGTH = 2000

    /**
     * Parses a one-line JSON request into (requestId, command).
     * Returns null when the payload is not valid JSON or has no usable command.
     */
    fun parseRequest(line: String): Pair<String, String>? {
        return try {
            val json = JSONObject(line)
            val cmd = json.optString("cmd", "")
            val requestId = json.optString("requestId", "")

            if (cmd.isBlank() || cmd.length > MAX_COMMAND_LENGTH) null
            else Pair(requestId, cmd)
        } catch (e: Exception) {
            null
        }
    }

    fun createErrorResponse(requestId: String, error: String): String {
        return """{"requestId":"$requestId","status":"error","result":"$error"}"""
    }

    fun escapeJson(s: String): String {
        return s
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }
}
