package com.openjarvis.commands

/**
 * Pure-JVM parser for spoken Turkish answers to a pending sensitive-action
 * confirmation (issue #5): "evet", "hayır", "iptal", ...
 *
 * Exact normalized-phrase matching only. Utterances that are not clearly a
 * confirmation or a cancellation return [Decision.None] so the caller can fall
 * back to its normal flow instead of guessing intent.
 */
object VoiceDecision {

    enum class Decision { Confirm, Cancel, None }

    fun parse(utterance: String): Decision {
        val normalized = normalize(utterance)
        if (normalized.isEmpty()) return Decision.None
        if (normalized in CONFIRM_PHRASES) return Decision.Confirm
        if (normalized in CANCEL_PHRASES) return Decision.Cancel
        return Decision.None
    }

    /** Turkish-aware lowercase; punctuation dropped; whitespace collapsed. */
    internal fun normalize(utterance: String): String =
        TurkishCommandRouter.toLowerTr(utterance)
            .filter { it.isLetterOrDigit() || it.isWhitespace() }
            .trim()
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() }
            .joinToString(" ")

    private val CONFIRM_PHRASES = setOf(
        "evet",
        "evet gönder",
        "evet gonder",
        "evet ara",
        "onayla",
        "onaylıyorum",
        "onayliyorum",
        "tamam",
        "gönder",
        "gonder",
        "ara"
    )

    private val CANCEL_PHRASES = setOf(
        "hayır",
        "hayir",
        "iptal",
        "iptal et",
        "vazgeç",
        "vazgec",
        "gönderme",
        "gonderme",
        "arama"
    )
}
