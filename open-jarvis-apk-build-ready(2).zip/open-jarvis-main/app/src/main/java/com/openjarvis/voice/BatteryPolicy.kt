package com.openjarvis.voice

/**
 * Pure-JVM battery policy for the continuous wake-word listening mode.
 *
 * Continuous listening restarts SpeechRecognizer in a loop, which consumes
 * noticeable battery. The service therefore pauses itself on a low battery
 * unless the device is charging, and reports the reason to the user in
 * Turkish instead of pretending to be always-on.
 */
object BatteryPolicy {

    /** Minimum battery percentage (device not charging) required to keep listening. */
    const val DEFAULT_MIN_LEVEL = 15

    fun decide(
        batteryLevelPercent: Int,
        isCharging: Boolean,
        minLevelPercent: Int = DEFAULT_MIN_LEVEL
    ): BatteryDecision {
        val level = batteryLevelPercent.coerceIn(0, 100)
        return if (isCharging || level >= minLevelPercent) {
            BatteryDecision.Run
        } else {
            BatteryDecision.Pause(
                "Pil seviyesi düşük (%$level%%). Sürekli dinleme pil tasarrufu için duraklatıldı; " +
                    "cihazı şarj ederken veya pili yeterli olduğunda Jarvis'i yeniden başlatabilirsiniz."
            )
        }
    }
}

sealed interface BatteryDecision {
    /** Battery level is sufficient (or charging); keep listening. */
    object Run : BatteryDecision

    /** Battery is low and the device is not charging; pause listening. */
    data class Pause(val reason: String) : BatteryDecision
}
