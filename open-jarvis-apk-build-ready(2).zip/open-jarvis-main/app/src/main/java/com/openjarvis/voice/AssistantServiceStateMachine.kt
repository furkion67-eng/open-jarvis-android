package com.openjarvis.voice

/**
 * Pure-JVM lifecycle state machine for the foreground assistant service.
 *
 * The service reports every event through [AssistantServiceController]; this
 * reducer owns the transition rules so lifecycle behavior is unit-testable
 * on the JVM without Android.
 */
object AssistantServiceStateMachine {

    fun reduce(current: AssistantServiceState, event: AssistantServiceEvent): AssistantServiceState =
        when (event) {
            is AssistantServiceEvent.StartRequested -> when (current) {
                is AssistantServiceState.Listening,
                is AssistantServiceState.AwaitingCommand,
                AssistantServiceState.Starting -> current // already running; keep it
                else -> AssistantServiceState.Starting
            }

            AssistantServiceEvent.ServiceReady -> when (current) {
                AssistantServiceState.Starting -> AssistantServiceState.Listening
                else -> current
            }

            is AssistantServiceEvent.WakeWordHeard -> when (current) {
                is AssistantServiceState.Listening,
                AssistantServiceState.Starting ->
                    if (event.command.isBlank()) {
                        AssistantServiceState.AwaitingCommand(
                            "Jarvis dinliyor. Komutunuzu söyleyin (örneğin: \"Sıla'ya SMS gönder\")."
                        )
                    } else {
                        AssistantServiceState.CommandDispatched(event.command)
                    }
                else -> current
            }

            is AssistantServiceEvent.CommandDispatched -> AssistantServiceState.Listening

            is AssistantServiceEvent.Failed -> AssistantServiceState.Error(event.message)

            is AssistantServiceEvent.PausedForBattery -> AssistantServiceState.Paused(event.reason)

            AssistantServiceEvent.StoppedByUser, AssistantServiceEvent.ServiceDestroyed ->
                AssistantServiceState.NotRunning
        }

    /**
     * Resolves a raw recognizer result against the current state.
     * While [AssistantServiceState.AwaitingCommand], the next utterance is
     * taken as the command itself (the user already said "Jarvis"); otherwise
     * the wake-word detector must be triggered first.
     */
    fun resolveUtterance(state: AssistantServiceState, recognizedText: String): UtteranceResolution =
        when (state) {
            is AssistantServiceState.AwaitingCommand ->
                if (recognizedText.isBlank()) UtteranceResolution.Ignore
                else UtteranceResolution.DispatchCommand(recognizedText)
            else ->
                when (val detection = WakeWordDetector.detect(recognizedText)) {
                    is Detection.Command -> UtteranceResolution.DispatchCommand(detection.text)
                    Detection.WakeOnly -> UtteranceResolution.WaitForCommand
                    Detection.None -> UtteranceResolution.Ignore
                }
        }

    /** True when the foreground service is expected to be alive and holding state. */
    fun isServiceActive(state: AssistantServiceState): Boolean = when (state) {
        AssistantServiceState.Starting,
        is AssistantServiceState.Listening,
        is AssistantServiceState.AwaitingCommand,
        is AssistantServiceState.CommandDispatched -> true
        else -> false
    }

    /** Turkish one-line status used by the dashboard card and the notification. */
    fun statusText(state: AssistantServiceState): String = when (state) {
        AssistantServiceState.NotRunning -> "Jarvis kapalı. Başlatmak için dokunun."
        AssistantServiceState.Starting -> "Jarvis başlatılıyor..."
        is AssistantServiceState.Listening -> "Jarvis dinliyor. Söyleyin: \"Jarvis\" + komutunuz."
        is AssistantServiceState.AwaitingCommand -> state.prompt
        is AssistantServiceState.CommandDispatched -> "Komut çalıştırılıyor: " + state.command
        is AssistantServiceState.Paused -> state.reason
        is AssistantServiceState.Error -> "Hata: " + state.message
    }
}

/** Events driving [AssistantServiceStateMachine]; all transitions are pure JVM. */
sealed interface AssistantServiceEvent {    object StartRequested : AssistantServiceEvent
    object ServiceReady : AssistantServiceEvent
    data class WakeWordHeard(val command: String) : AssistantServiceEvent
    data class CommandDispatched(val command: String) : AssistantServiceEvent
    data class Failed(val message: String) : AssistantServiceEvent
    data class PausedForBattery(val reason: String) : AssistantServiceEvent
    object StoppedByUser : AssistantServiceEvent
    object ServiceDestroyed : AssistantServiceEvent
}

/** Outcome of resolving one recognizer result in the current state. */
sealed interface UtteranceResolution {
    /** Execute this text as a JARVIS command. */
    data class DispatchCommand(val command: String) : UtteranceResolution

    /** Wake word heard without a command; keep listening for the command. */
    object WaitForCommand : UtteranceResolution

    /** Not addressed to JARVIS; ignore and keep listening. */
    object Ignore : UtteranceResolution
}
