package com.openjarvis.commands

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

/**
 * Permission-aware execution of local Android actions (issue #5).
 *
 * Honesty rules:
 * - A message is reported as "sent" only from a confirmed SMS send result.
 * - Without SEND_SMS, the SMS app is opened prefilled instead and the user is
 *   told to press send there; without CALL_PHONE, the dialer is opened.
 * - Missing contacts permission is reported, never silently ignored.
 */
class AndroidActionExecutor(private val context: Context) {

    sealed class ContactResolution {
        data class Exact(val number: String, val displayName: String) : ContactResolution()
        data class Ambiguous(val candidates: List<ContactMatcher.Match>) : ContactResolution()
        object NotFound : ContactResolution()
        object PermissionMissing : ContactResolution()
    }

    fun canSendSmsDirectly(): Boolean = hasPermission(Manifest.permission.SEND_SMS)
    fun canCallDirectly(): Boolean = hasPermission(Manifest.permission.CALL_PHONE)
    fun canReadContacts(): Boolean = hasPermission(Manifest.permission.READ_CONTACTS)

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun resolveContactNumber(name: String): ContactResolution {
        if (!canReadContacts()) return ContactResolution.PermissionMissing
        val pairs = mutableListOf<Pair<String, String>>()
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )?.use { cursor ->
                val nameIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && pairs.size < 500) {
                    val displayName = cursor.getString(nameIndex)
                    val number = cursor.getString(numberIndex)
                    if (!displayName.isNullOrBlank() && !number.isNullOrBlank()) {
                        pairs.add(displayName to number)
                    }
                }
            } ?: return ContactResolution.NotFound
        } catch (e: SecurityException) {
            return ContactResolution.PermissionMissing
        } catch (e: Exception) {
            return ContactResolution.NotFound
        }
        return when (val match = ContactMatcher.bestMatch(name, pairs)) {
            is ContactMatcher.BestMatch.Exact -> ContactResolution.Exact(match.match.value, match.match.label)
            is ContactMatcher.BestMatch.Ambiguous -> ContactResolution.Ambiguous(match.candidates)
            ContactMatcher.BestMatch.NotFound -> ContactResolution.NotFound
        }
    }

    /** Sends [body] to [number]; [onResult] is invoked exactly once. */
    fun sendSms(number: String, body: String, onResult: (Result<Unit>) -> Unit) {
        val sentAction = "com.openjarvis.commands.SMS_SENT"
        // The telephony stack fills in result extras on this PendingIntent, so it
        // must stay mutable on Android 12+.
        val pendingIntentFlags = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_MUTABLE
        } else {
            android.app.PendingIntent.FLAG_UPDATE_CURRENT
        }
        val sentPendingIntent = android.app.PendingIntent.getBroadcast(
            context,
            (number + body).hashCode(),
            Intent(sentAction).setPackage(context.packageName),
            pendingIntentFlags
        )
        var delivered = false
        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(receiveContext: Context?, intent: Intent?) {
                if (delivered) return
                delivered = true
                (receiveContext ?: context).unregisterReceiver(this)
                if (resultCode == android.app.Activity.RESULT_OK) {
                    onResult(Result.success(Unit))
                } else {
                    onResult(Result.failure(IllegalStateException("Android SMS gönderim sonucu: resultCode=$resultCode")))
                }
            }
        }
        try {
            ContextCompat.registerReceiver(
                context,
                receiver,
                android.content.IntentFilter(sentAction),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            val smsManager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            } ?: run {
                context.unregisterReceiver(receiver)
                onResult(Result.failure(IllegalStateException("Bu cihazda SmsManager yok")))
                return
            }
            if (body.length <= 160) {
                smsManager.sendTextMessage(number, null, body, sentPendingIntent, null)
            } else {
                smsManager.sendMultipartTextMessage(number, null, smsManager.divideMessage(body), arrayListOf(sentPendingIntent), null)
            }
        } catch (e: Exception) {
            runCatching { context.unregisterReceiver(receiver) }
            onResult(Result.failure(e))
        }
    }

    /** Opens the default SMS app with recipient and body prefilled (no SEND_SMS needed). */
    fun openSmsApp(number: String, body: String): Boolean = try {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
            putExtra("sms_body", body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: Exception) {
        false
    }

    /** Places the call directly (CALL_PHONE) or opens the dialer for the user. */
    fun placeCall(number: String, directIfPermitted: Boolean): Boolean = try {
        val direct = directIfPermitted && canCallDirectly()
        val action = if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL
        context.startActivity(Intent(action, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    /** Opens a WhatsApp chat; text is prefilled but never auto-sent. */
    fun openWhatsAppChat(number: String?, body: String?): Boolean = try {
        val uri = if (number.isNullOrBlank()) {
            "https://wa.me/"
        } else {
            val digits = number.filter { it.isDigit() }
            val international = when {
                digits.startsWith("90") -> digits
                digits.startsWith("0") -> "90" + digits.drop(1)
                else -> "90$digits"
            }
            "https://wa.me/$international"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
            setPackage("com.whatsapp")
            if (!body.isNullOrBlank()) putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            intent.setPackage(null)
            context.startActivity(intent)
        }
        true
    } catch (e: Exception) {
        false
    }

    fun resolveAppPackage(label: String): String? {
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = try {
            context.packageManager.queryIntentActivities(launcherIntent, 0)
        } catch (e: Exception) {
            return null
        }
        val candidates = apps.mapNotNull { info ->
            val appLabel = runCatching { info.loadLabel(context.packageManager).toString() }.getOrNull()
            if (appLabel.isNullOrBlank()) null else appLabel to info.activityInfo.packageName
        }
        return when (val match = ContactMatcher.bestMatch(label, candidates)) {
            is ContactMatcher.BestMatch.Exact -> match.match.value
            else -> null
        }
    }

    fun launchApp(packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
