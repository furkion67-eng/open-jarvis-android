package com.openjarvis.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import com.openjarvis.voice.AssistantServiceController
import com.openjarvis.voice.AssistantServiceStateMachine
import com.openjarvis.ui.theme.VoidColor

/**
 * Dashboard card for the foreground assistant service (issue #7).
 * Shows the real service state in Turkish and an explicit start/stop
 * control. Honest labels: continuous listening uses battery and pauses
 * automatically on a low battery unless charging.
 */
@Composable
fun AssistantServiceCard(onToggle: (start: Boolean) -> Unit) {
    val state by AssistantServiceController.state.collectAsState()
    val active = AssistantServiceStateMachine.isServiceActive(state)
    val statusText = AssistantServiceStateMachine.statusText(state)

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = VoidColor.Void900,
        border = androidx.compose.foundation.BorderStroke(1.dp, VoidColor.BorderGlow)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "JARVIS SERVİSİ",
                style = TextStyle(
                    fontWeight = FontWeight(600),
                    fontSize = 11.sp,
                    letterSpacing = 2.sp,
                    color = VoidColor.Violet
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = statusText,
                style = TextStyle(fontWeight = FontWeight(400), fontSize = 13.sp, color = VoidColor.TextPrimary)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (!active) {
                    Button(
                        onClick = { onToggle(true) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Jarvis'ı başlat") }
                } else {
                    OutlinedButton(
                        onClick = { onToggle(false) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Jarvis'ı durdur") }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Sürekli dinleme pili kullanır; pil zayıfken (şarjda değilken) otomatik duraklar.",
                fontSize = 11.sp,
                color = VoidColor.TextSecondary
            )
        }
    }
}
