package com.openjarvis.commands

/**
 * Pure-JVM resolution of a spoken answer to an ambiguous-contact prompt
 * (issue #5): "Sıla için 2 eşleşme var" must never become a dead end.
 *
 * The prompt numbers the candidates (1., 2., ...), so the answer can be an
 * ordinal ("birinci", "iki"), a number ("2"), a phone number spoken back,
 * or a fuller contact name. Everything else is [Result.Unmatched]; the caller
 * re-prompts instead of guessing (never invents a contact).
 */
object ContactChoiceSelector {

    sealed class Result {
        /** Exactly one candidate selected. */
        data class Selected(val match: ContactMatcher.Match, val index: Int) : Result()

        /** The answer is not clearly any candidate (or matches several equally). */
        object Unmatched : Result()
    }

    fun select(utterance: String, candidates: List<ContactMatcher.Match>): Result {
        if (candidates.isEmpty()) return Result.Unmatched
        val text = VoiceDecision.normalize(utterance)
        if (text.isEmpty()) return Result.Unmatched

        ordinalIndex(text, candidates.size)?.let { index ->
            return Result.Selected(candidates[index], index)
        }

        // Spoken-back phone number: compare digits only.
        val digits = text.filter { it.isDigit() }
        if (digits.length >= 6) {
            val hits = candidates.withIndex().filter { (_, c) ->
                c.value.filter { it.isDigit() }.endsWith(digits) ||
                    digits.endsWith(c.value.filter { it.isDigit() })
            }
            if (hits.size == 1) {
                return Result.Selected(hits[0].value, hits[0].index)
            }
        }

        // Full or partial spoken name.
        val scored = candidates.withIndex().mapNotNull { (index, candidate) ->
            val s = ContactMatcher.score(text, candidate.label)
            if (s >= 50) index to s else null
        }
        if (scored.size == 1) {
            val (index, _) = scored[0]
            return Result.Selected(candidates[index], index)
        }
        return Result.Unmatched
    }

    /** Maps ordinal words/numbers ("birinci", "iki", "3") to a 0-based index. */
    private fun ordinalIndex(normalized: String, candidateCount: Int): Int? {
        val trimmed = normalized.trim()
        val asNumber = trimmed.filter { it.isDigit() }
        if (asNumber.isNotEmpty() && asNumber.length == trimmed.length) {
            val n = asNumber.toIntOrNull() ?: return null
            return if (n in 1..candidateCount) n - 1 else null
        }
        ORDINAL_WORDS.forEachIndexed { i, words ->
            if (trimmed in words && i < candidateCount) return i
        }
        return null
    }

    // Index i of this list selects candidate i+1. Each set holds accepted
    // variants including common STT spellings.
    private val ORDINAL_WORDS: List<Set<String>> = listOf(
        setOf("bir", "birinci", "1.", "1", "ilk"),
        setOf("iki", "ikinci", "2.", "2"),
        setOf("üç", "uc", "üçüncü", "ucuncu", "3.", "3"),
        setOf("dört", "dort", "dördüncü", "dorduncu", "4.", "4"),
        setOf("beş", "bes", "beşinci", "besinci", "5.", "5")
    )
}
