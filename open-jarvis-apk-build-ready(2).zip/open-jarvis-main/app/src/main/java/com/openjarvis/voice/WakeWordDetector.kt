package com.openjarvis.voice

/**
 * Pure-JVM wake-word detection for Turkish voice sessions.
 *
 * SpeechRecognizer output is matched against the wake word "Jarvis" with a
 * small edit distance so common mis-recognitions (for example "jervis",
 * "jarvis'i") still trigger, while unrelated speech does not.
 */
object WakeWordDetector {

    const val WAKE_WORD = "jarvis"
    const val MAX_EDIT_DISTANCE = 1

    /** Normalizes recognizer output: lowercase, strip punctuation, split tokens. */
    fun normalize(text: String?): List<String> {
        if (text.isNullOrBlank()) return emptyList()
        val lowered = text.lowercase()
            .replace('ı', 'i') // Turkish dotless i normalizes for matching
        return lowered.split(Regex("[\\s.,!?;:()\\[\\]'\u2019\"-]+"))
            .filter { it.isNotBlank() }
    }

    /**
     * Detects the wake word in recognized speech.
     * @return [Detection.Command] with the text spoken after the wake word,
     *         [Detection.WakeOnly] when only the wake word was heard, or
     *         [Detection.None] when the wake word was not present.
     */
    fun detect(text: String?): Detection {
        val tokens = normalize(text)
        val index = tokens.indexOfFirst { matchesWakeWord(it) }
        if (index < 0) return Detection.None
        val rest = tokens.drop(index + 1).joinToString(" ")
        return if (rest.isBlank()) Detection.WakeOnly else Detection.Command(rest)
    }

    fun matchesWakeWord(token: String): Boolean =
        levenshtein(token, WAKE_WORD) <= MAX_EDIT_DISTANCE

    /** Classic dynamic-programming Levenshtein distance (pure JVM). */
    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + cost)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}

sealed interface Detection {
    /** Wake word heard and a command followed it. */
    data class Command(val text: String) : Detection

    /** Wake word heard with nothing after it yet. */
    object WakeOnly : Detection

    /** Wake word not present in the recognized text. */
    object None : Detection
}
