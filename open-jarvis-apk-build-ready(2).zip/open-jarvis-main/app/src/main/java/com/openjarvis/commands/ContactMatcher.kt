package com.openjarvis.commands

/**
 * Pure-JVM fuzzy contact/app-label matching used by the local action executor.
 * No Android APIs — safe for unit tests.
 */
object ContactMatcher {

    /** Lowercases and strips Turkish diacritics for forgiving matching. */
    fun normalize(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            val lower = when (c) {
                'İ' -> 'i'
                'I' -> 'ı'
                else -> c.lowercaseChar()
            }
            sb.append(
                when (lower) {
                    'ç' -> 'c'
                    'ğ' -> 'g'
                    'ı' -> 'i'
                    'ö' -> 'o'
                    'ş' -> 's'
                    'ü' -> 'u'
                    else -> lower
                }
            )
        }
        return sb.toString()
    }

    fun score(query: String, candidate: String): Int {
        val q = normalize(query).trim()
        val c = normalize(candidate).trim()
        if (q.isEmpty() || c.isEmpty()) return 0
        return when {
            q == c -> 100
            c.startsWith(q) -> 80
            c.contains(q) -> 60
            q.length >= 4 && c.length >= 4 && levenshtein(q, c) <= 2 -> 50
            else -> 0
        }
    }

    data class Match(val label: String, val value: String, val score: Int)

    sealed class BestMatch {
        data class Exact(val match: Match) : BestMatch()
        data class Ambiguous(val candidates: List<Match>) : BestMatch()
        object NotFound : BestMatch()
    }

    /**
     * Finds the best candidate for [query] among (label, value) pairs.
     * Two distinct labels with equal top score are reported as [BestMatch.Ambiguous]
     * so the caller can refuse to guess (issue #5: never invent a contact).
     */
    fun <T> bestMatch(query: String, candidates: List<Pair<String, T>>): BestMatch {
        if (candidates.isEmpty()) return BestMatch.NotFound
        val scored = candidates
            .mapNotNull { (label, value) ->
                val s = score(query, label)
                if (s > 0) Match(label, value.toString(), s) else null
            }
        if (scored.isEmpty()) return BestMatch.NotFound
        val top = scored.maxByOrNull { it.score }!!
        val ties = scored.filter { it.score == top.score }
        val distinctLabels = ties.map { normalize(it.label) }.distinct()
        return if (distinctLabels.size > 1 && top.score < 100) {
            BestMatch.Ambiguous(ties.sortedByDescending { it.score }.take(5))
        } else {
            BestMatch.Exact(top)
        }
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var previous = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val current = IntArray(b.length + 1)
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + cost)
            }
            previous = current
        }
        return previous[b.length]
    }
}
