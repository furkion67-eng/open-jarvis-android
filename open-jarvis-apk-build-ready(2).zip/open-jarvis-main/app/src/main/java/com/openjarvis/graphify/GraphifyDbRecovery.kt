package com.openjarvis.graphify

import java.io.File
import java.io.FileInputStream

/**
 * JVM-pure recovery helpers for the Graphify Room database.
 *
 * The app schema is at version 3 and only ships MIGRATION_2_3. A device that
 * upgraded from an early build (or any install with a corrupt/downgraded
 * graphify.db) would otherwise crash with
 * "A migration from 1 to 3 was required but not found" on the first Room query.
 * The database file is renamed (never deleted) so user data stays recoverable.
 */
object GraphifyDbRecovery {

    /** Suffix appended to backed-up database files, followed by a timestamp. */
    const val RECOVERY_SUFFIX = "unmigratable"

    private val SQLITE_MAGIC = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)

    /** Schema versions Room can migrate to the current schema (3). */
    private val MIGRATABLE_SCHEMA_VERSIONS = setOf(2, 3)

    private const val HEADER_SIZE = 100
    private const val VERSION_OFFSET = 44

    /**
     * True when the given SQLite header cannot be opened by the current schema
     * and the database file should be backed up before Room creates a fresh one.
     */
    fun shouldRecoverFromHeader(header: ByteArray): Boolean {
        if (header.size < HEADER_SIZE) return true
        for (i in SQLITE_MAGIC.indices) {
            if (header[i] != SQLITE_MAGIC[i]) return true
        }
        val version = ((header[VERSION_OFFSET].toInt() and 0xFF) shl 24) or
            ((header[VERSION_OFFSET + 1].toInt() and 0xFF) shl 16) or
            ((header[VERSION_OFFSET + 2].toInt() and 0xFF) shl 8) or
            (header[VERSION_OFFSET + 3].toInt() and 0xFF)
        return version !in MIGRATABLE_SCHEMA_VERSIONS
    }

    /**
     * Renames an un-migratable/corrupt [dbFile] (plus its -wal/-shm/-journal
     * sidecars) to "<name>.<suffix>-<timestamp>" and returns the renamed files.
     * A readable, migratable database is left untouched; a missing file is a no-op.
     */
    fun recoverUnmigratableDatabase(
        dbFile: File,
        now: Long = System.currentTimeMillis()
    ): List<File> {
        if (!dbFile.isFile) return emptyList()

        val header = ByteArray(HEADER_SIZE)
        FileInputStream(dbFile).use { input ->
            var offset = 0
            while (offset < HEADER_SIZE) {
                val read = input.read(header, offset, HEADER_SIZE - offset)
                if (read <= 0) break
                offset += read
            }
            if (offset < HEADER_SIZE && dbFile.length() >= HEADER_SIZE) {
                // Partial read on a file that should have a full header: leave it alone.
                return emptyList()
            }
            if (!shouldRecoverFromHeader(header.copyOf(offset))) return emptyList()
        }

        val stamp = "$RECOVERY_SUFFIX-$now"
        val sidecars = dbFile.parentFile
            ?.listFiles { f -> f.name.startsWith("${dbFile.name}-") }
            ?.sortedBy { it.name }
            .orEmpty()
        val renamed = mutableListOf<File>()
        for (file in listOf(dbFile) + sidecars) {
            if (!file.exists()) continue
            val target = File(file.parentFile, "${file.name}.$stamp")
            if (file.renameTo(target)) renamed.add(target)
        }
        return renamed
    }
}
