package com.openjarvis.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.openjarvis.R
import com.openjarvis.agent.AgentCore
import com.openjarvis.ui.MainActivity

/**
 * Foreground assistant service (issue #7).
 *
 * Started explicitly from the dashboard UI. Runs a battery-aware Turkish
 * wake-word listening loop ("Jarvis" + command), shows a persistent status
 * notification with a stop action, and reports every lifecycle transition
 * through [AssistantServiceController] so the UI shows real state.
 *
 * Failure handling: initialization problems (missing microphone permission,
 * no recognition service, low battery) are reported honestly as
 * [AssistantServiceState.Error]/[Paused] and the service stops itself —
 * it never crashes the host process.
 */
class AssistantService : Service() {

    private var recognizer: SpeechRecognizer? = null
    private var agent: AgentCore? = null
    private var running = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var restartRunnable: RestartCycle? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopListeningLoop()
                AssistantServiceController.dispatch(AssistantServiceEvent.StoppedByUser)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> startAssistant()
        }
        return START_STICKY
    }

    private fun startAssistant() {
        val current = AssistantServiceController.state.value
        if (AssistantServiceStateMachine.isServiceActive(current)) {
            return // already running
        }
        AssistantServiceController.dispatch(AssistantServiceEvent.StartRequested)

        // Always enter foreground first (specialUse type is permission-safe) so
        // every early-exit path below can stop cleanly without a
        // ForegroundServiceDidNotStartInTimeException crash.
        val entered = startInForeground(microphoneType = false)
        if (!entered) {
            AssistantServiceController.dispatch(
                AssistantServiceEvent.Failed("Jarvis servisi ön planda başlatılamadı.")
            )
            stopSelf()
            return
        }

        val initFailure = runCatching { initializeAssistant() }
            .exceptionOrNull()?.message
        if (initFailure != null) {
            AssistantServiceController.dispatch(
                AssistantServiceEvent.Failed("Jarvis başlatılamadı: $initFailure")
            )
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    /**
     * Guarded initialization: every failure path posts an honest state and
     * returns false so [startAssistant] stops the service without crashing.
     */
    private fun initializeAssistant(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            AssistantServiceController.dispatch(
                AssistantServiceEvent.Failed(
                    "Mikrofon izni verilmedi. Uygulama ayarlarından mikrofon iznini verin " +
                        "ve Jarvis'i yeniden başlatın."
                )
            )
            return false
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            AssistantServiceController.dispatch(
                AssistantServiceEvent.Failed(
                    "Bu cihazda konuşma tanıma hizmeti bulunamadı. " +
                        "Sürekli dinleme modu kullanılamaz."
                )
            )
            return false
        }

        val battery = readBatteryLevel()
        when (val decision = BatteryPolicy.decide(battery.level, battery.isCharging)) {
            is BatteryDecision.Pause -> {
                AssistantServiceController.dispatch(
                    AssistantServiceEvent.PausedForBattery(decision.reason)
                )
                return false
            }
            BatteryDecision.Run -> Unit
        }

        val core = runCatching { AgentCore(applicationContext) }.getOrNull()
        if (core == null) {
            AssistantServiceController.dispatch(
                AssistantServiceEvent.Failed(
                    "Jarvis çekirdeği başlatılamadı. Uygulamayı yeniden başlatıp tekrar deneyin."
                )
            )
            return false
        }
        agent = core

        startInForeground(microphoneType = true)
        createRecognizer()
        running = true
        AssistantServiceController.dispatch(AssistantServiceEvent.ServiceReady)
        scheduleRestartCycle(RESTART_DELAY_MS)
        return true
    }

    /**
     * Enters foreground with the requested type. The microphone type requires
     * RECORD_AUDIO + while-in-use state; the specialUse type is used for the
     * guaranteed initial entry and for any failure path.
     */
    private fun startInForeground(microphoneType: Boolean): Boolean {
        val notification = createNotification()
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val type =
                    if (microphoneType) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                startForeground(NOTIFICATION_ID, notification, type)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (e: Exception) {
            // Honest failure (for example: system restart from background while
            // mic while-in-use is not allowed). Never crash the host process.
            runCatching { startForeground(NOTIFICATION_ID, notification) }
                .onFailure { stopSelf() }
            false
        }
    }

    private fun createRecognizer() {
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

            override fun onError(error: Int) {
                if (!running) return
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    AssistantServiceController.dispatch(
                        AssistantServiceEvent.Failed(
                            "Mikrofon izni verilmedi. Sürekli dinleme durduruldu."
                        )
                    )
                    stopListeningLoop()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return
                }
                // No match / timeouts are normal in continuous listening: retry.
                scheduleRestartCycle(RESTART_DELAY_MS)
            }

            override fun onResults(results: android.os.Bundle?) {
                if (!running) return
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.trim()
                handleUtterance(text)
                scheduleRestartCycle(RESTART_DELAY_MS)
            }
        })
        listenOnce()
    }

    private fun listenOnce() {
        val rec = recognizer ?: return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        runCatching { rec.startListening(intent) }
    }

    private fun handleUtterance(text: String?) {
        if (text.isNullOrBlank()) return
        when (
            val resolution =
                AssistantServiceStateMachine.resolveUtterance(AssistantServiceController.state.value, text)
        ) {
            is UtteranceResolution.DispatchCommand -> {
                AssistantServiceController.dispatch(
                    AssistantServiceEvent.WakeWordHeard(resolution.command)
                )
                val command = resolution.command
                val core = agent
                if (core != null) {
                    mainHandler.post {
                        runCatching { core.executeTask(command) }
                            .onFailure {
                                AssistantServiceController.dispatch(
                                    AssistantServiceEvent.Failed(
                                        "Komut çalıştırılamadı: ${it.message ?: "bilinmeyen hata"}"
                                    )
                                )
                            }
                    }
                }
                AssistantServiceController.dispatch(AssistantServiceEvent.CommandDispatched(command))
            }
            UtteranceResolution.WaitForCommand ->
                AssistantServiceController.dispatch(AssistantServiceEvent.WakeWordHeard(""))
            UtteranceResolution.Ignore -> Unit
        }
    }

    /** One restart cycle: re-check battery, then listen again. */
    private inner class RestartCycle : Runnable {
        override fun run() {
            if (!running) return
            val battery = readBatteryLevel()
            when (val decision = BatteryPolicy.decide(battery.level, battery.isCharging)) {
                is BatteryDecision.Pause -> {
                    AssistantServiceController.dispatch(
                        AssistantServiceEvent.PausedForBattery(decision.reason)
                    )
                    stopListeningLoop()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return
                }
                BatteryDecision.Run -> Unit
            }
            listenOnce()
        }
    }

    private fun scheduleRestartCycle(delayMillis: Long) {
        restartRunnable?.let(mainHandler::removeCallbacks)
        val cycle = RestartCycle()
        restartRunnable = cycle
        mainHandler.postDelayed(cycle, delayMillis)
    }

    private fun stopListeningLoop() {
        running = false
        restartRunnable?.let(mainHandler::removeCallbacks)
        restartRunnable = null
        runCatching { recognizer?.stopListening() }
    }

    private data class BatteryReading(val level: Int, val isCharging: Boolean)

    private fun readBatteryLevel(): BatteryReading {
        return runCatching {
            val sticky = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val levelRaw = sticky?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scaleRaw = sticky?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = sticky?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging =
                status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            val level = if (levelRaw in 0..100) levelRaw
            else if (levelRaw >= 0 && scaleRaw > 0) (levelRaw * 100 / scaleRaw)
            else 100
            BatteryReading(level, isCharging)
        }.getOrDefault(BatteryReading(100, true))
    }

    private fun createNotification(): Notification {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_description)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopSelf = PendingIntent.getService(
            this,
            1,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText("Sürekli dinleme açık. Söyleyin: \"Jarvis\" + komutunuz.")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(0, "Durdur", stopSelf)
            .build()
    }

    override fun onDestroy() {
        stopListeningLoop()
        runCatching { recognizer?.destroy() }
        recognizer = null
        AssistantServiceController.dispatch(AssistantServiceEvent.ServiceDestroyed)
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "jarvis_assistant_channel"
        private const val NOTIFICATION_ID = 2
        private const val RESTART_DELAY_MS = 500L

        const val ACTION_START = "com.openjarvis.voice.START_ASSISTANT"
        const val ACTION_STOP = "com.openjarvis.voice.STOP_ASSISTANT"

        /** Explicit user opt-in start from the UI (foreground context). */
        fun start(context: Context) {
            val intent = Intent(context, AssistantService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, AssistantService::class.java).setAction(ACTION_STOP)
            )
        }
    }
}
