package com.openjarvis.commands

/**
 * Deterministic classification of Turkish voice/text commands into supported
 * local Android actions. Pure Kotlin (JVM-testable); no Android APIs.
 *
 * When [route] returns non-null, the command must be executed locally and the
 * LLM must not be asked for an action plan (issue #5: the model must not answer
 * "I cannot send SMS" when a supported local action exists).
 *
 * Extraction is intentionally conservative: anything not confidently matched
 * returns null and falls back to the normal LLM/chat flow.
 */
sealed class RoutedCommand {
    /** Send an SMS. [contactName] xor [phoneNumber] is normally set. */
    data class SendSms(
        val contactName: String?,
        val phoneNumber: String?,
        val messageBody: String?
    ) : RoutedCommand()

    /** Call a contact or number. */
    data class MakeCall(
        val contactName: String?,
        val phoneNumber: String?
    ) : RoutedCommand()

    /** Launch an installed app by (approximate) label. */
    data class OpenApp(
        val appName: String
    ) : RoutedCommand()

    /** Open a WhatsApp chat with prefilled text. Never claims a message was sent. */
    data class WhatsAppMessage(
        val contactName: String?,
        val phoneNumber: String?,
        val messageBody: String?
    ) : RoutedCommand()
}

object TurkishCommandRouter {

    /** Length-preserving Turkish lowercase so spans map back onto the raw text. */
    internal fun toLowerTr(text: String): String {
        val sb = StringBuilder(text.length)
        for (c in text) {
            sb.append(
                when (c) {
                    'İ' -> 'i'
                    'I' -> 'ı'
                    else -> c.lowercaseChar()
                }
            )
        }
        return sb.toString()
    }

    private val SEND_VERB = """(?:gönder|gonder|at|yolla|gönderir misin|gonderir misin|göndermisin|gönderir|mısın)"""

    // WhatsApp first so "sıla'ya whatsapp mesajı gönder" is not treated as plain SMS.
    private val WHATSAPP_PATTERNS = listOf(
        // "whatsapp'ta sıla'ya selam diye mesaj gönder"
        Regex("""^\s*whatsapp(?:'?t[ae]|'?d[ae])?\s+(?<recipient>.+?)\s+diye\s+(?<body>.+?)\s+(?:mesaj(?:ını)?\s+)?$SEND_VERB\s*[.!?]?\s*$"""),
        // "whatsapp'ta sıla'ya selam gönder" / "whatsapp'ta sıla'ya mesaj gönder"
        Regex("""^\s*whatsapp(?:'?t[ae]|'?d[ae])?\s+(?<recipient>.+?)\s+(?:mesaj(?:ını)?\s*)?(?<body>.*?)\s*$SEND_VERB\s*[.!?]?\s*$"""),
        // "sıla'ya whatsapp mesajı gönder" / "sıla'ya whatsapp gönder"
        Regex("""^\s*(?<recipient>.+?)\s+whatsapp(?:\s+mesajı)?\s*$SEND_VERB\s*[.!?]?\s*$""")
    )

    private val SMS_PATTERNS = listOf(
        // 'sıla'ya "geç kaldım" diye sms gönder' — quoted body
        Regex("""^\s*(?<recipient>.+?)\s*(?:diye\s+)?[“”"«»„'](?<body>[^“”"«»„']+)[“”"«»„']\s*(?:diye\s+)?(?:mesaj|sms|ileti)(?:ını|ini|unu|ünü|nı|ni|ı|i|u|ü)?\s*$SEND_VERB\s*[.!?]?\s*$"""),
        // '0532 123 45 67 numarasına görüşürüz diye mesaj yolla' — explicit number + clause body
        Regex("""^\s*(?<recipient>[\d\s()+-]{10,})\s*(?:numarasına|numarasını|numarası|numaraya)\s+(?<body>.+?)\s+diye\s+(?:bir\s+)?(?:mesaj|sms|ileti)\s*$SEND_VERB\s*[.!?]?\s*$"""),
        // 'sıla'ya merhaba diye sms gönder' — clause body precedes "diye"
        Regex("""^\s*(?<recipient>.+?)\s+(?<body>.+?)\s+diye\s+(?:bir\s+)?(?:mesaj|sms|ileti)\s*$SEND_VERB\s*[.!?]?\s*$"""),
        // 'sıla'ya sms gönder' / 'anneme mesaj at' — no body
        Regex("""^\s*(?<recipient>.+?)\s+(?:bir\s+)?(?:mesaj|sms|ileti)\s*$SEND_VERB\s*[.!?]?\s*$""")
    )

    private val CALL_PATTERNS = listOf(
        // "sıla'yı ara" / "annemi telefonla ara" / "0532 123 45 67 numarasını ara"
        Regex("""^\s*(?<recipient>.+?)\s+(?:telefon(?:la|unu|u)\s+|telefonla\s+)?(?:numarasını\s+|numarasına\s+)?ara(?:r mısın|rmısın|malısın|ma yap|ınız)?\s*[.!?]?\s*$""")
    )

    private val APP_PATTERNS = listOf(
        // "youtube'u aç" / "kamera uygulamasını aç" / "ayarlari aç" / "haritaları başlat"
        Regex("""^\s*(?<app>.+?)\s*(?:uygulamasını|uygulamayı|uygulamamı|uygulamam)?\s*'?(?:u|ü|ı|i|nı|ni|yı|yi)?\s*(?:aç|açar mısın|açar mısınız|başlat|çalıştır)\s*[.!?]?\s*$""")
    )

    private val PHONE_CHARS = Regex("""[^0-9]""")

    fun route(rawCommand: String): RoutedCommand? {
        val command = rawCommand.trim()
        if (command.length < 4 || command.length > 300) return null
        val lowered = toLowerTr(command)

        return routeWhatsApp(lowered, command)
            ?: routeSms(lowered, command)
            ?: routeCall(lowered, command)
            ?: routeApp(lowered, command)
    }

    private fun routeWhatsApp(lowered: String, raw: String): RoutedCommand? {
        for (pattern in WHATSAPP_PATTERNS) {
            val match = pattern.find(lowered) ?: continue
            val recipientRaw = span(match, "recipient", raw) ?: continue
            val body = span(match, "body", raw)?.trim()?.takeIf { it.isNotBlank() }
            val (contactName, phoneNumber) = parseRecipient(recipientRaw)
            if (contactName == null && phoneNumber == null) continue
            return RoutedCommand.WhatsAppMessage(contactName, phoneNumber, body)
        }
        return null
    }

    private fun routeSms(lowered: String, raw: String): RoutedCommand? {
        for (pattern in SMS_PATTERNS) {
            val match = pattern.find(lowered) ?: continue
            val recipientRaw = span(match, "recipient", raw) ?: continue
            val body = span(match, "body", raw)?.trim()?.takeIf { it.isNotBlank() }
            val (contactName, phoneNumber) = parseRecipient(recipientRaw)
            if (contactName == null && phoneNumber == null) continue
            return RoutedCommand.SendSms(contactName, phoneNumber, body)
        }
        return null
    }

    private fun routeCall(lowered: String, raw: String): RoutedCommand? {
        for (pattern in CALL_PATTERNS) {
            val match = pattern.find(lowered) ?: continue
            val recipientRaw = span(match, "recipient", raw) ?: continue
            val (contactName, phoneNumber) = parseRecipient(recipientRaw)
            if (contactName == null && phoneNumber == null) continue
            return RoutedCommand.MakeCall(contactName, phoneNumber)
        }
        return null
    }

    private fun routeApp(lowered: String, raw: String): RoutedCommand? {
        for (pattern in APP_PATTERNS) {
            val match = pattern.find(lowered) ?: continue
            val appRaw = span(match, "app", raw)?.trim() ?: continue
            val name = cleanAppName(appRaw)
            if (name == null || name.length < 2) continue
            return RoutedCommand.OpenApp(name)
        }
        return null
    }

    private fun span(match: MatchResult, group: String, raw: String): String? {
        val range = try {
            match.groups[group]?.range ?: return null
        } catch (e: IllegalArgumentException) {
            // Pattern variant without this named group (for example, SMS without body).
            return null
        }
        return raw.substring(range).trim().takeIf { it.isNotEmpty() }
    }

    /** Returns (contactName, phoneNumber); at most one is non-null. */
    internal fun parseRecipient(recipientPhrase: String): Pair<String?, String?> {
        var phrase = recipientPhrase.trim().trimEnd('.', ',', '!', '?', ';', ':')
        val digits = PHONE_CHARS.replace(phrase, "")
        if (digits.length >= 10) {
            return null to digits
        }
        // Drop a trailing "numarasına/numarasını/numarası" qualifier.
        for (qualifier in listOf("numarasına", "numarasını", "numarasından", "numarası", "numaradan")) {
            if (phrase.length > qualifier.length + 2 && phrase.endsWith(qualifier)) {
                phrase = phrase.removeSuffix(qualifier).trim()
                break
            }
        }
        val contact = stripCaseSuffix(phrase)
        return if (contact.length >= 2) contact to null else null to null
    }

    /**
     * Strips the apostrophe'd case marker ("Sıla'ya" → "Sıla") and common
     * no-apostrophe case/possessive endings ("annemi" → "annem"). Over-stripping
     * is tolerated because contact matching is fuzzy (contains-based).
     */
    internal fun stripCaseSuffix(phrase: String): String {
        var p = phrase.trim().trimEnd('.', ',', '!', '?')
        val apostrophe = p.indexOfFirst { it == '\'' || it == '’' }
        if (apostrophe > 0) {
            val head = p.substring(0, apostrophe).trim()
            if (head.length >= 2) return head
        }
        val suffixes = listOf("nin", "nın", "nun", "nün", "nı", "ni", "nu", "nü", "ya", "ye", "yo", "yue", "ma", "me", "mı", "mi", "mu", "mü")
        if (p.length > 3) {
            for (suffix in suffixes) {
                if (p.endsWith(suffix) && p.length - suffix.length >= 2) {
                    return p.removeSuffix(suffix).trim()
                }
            }
        }
        return p
    }

    private fun cleanAppName(raw: String): String? {
        var name = raw.trim().trimEnd('.', ',', '!', '?')
        for (qualifier in listOf("uygulamasını", "uygulamayı", "uygulamamı", "uygulamam", "uygulaması", "uygulama")) {
            if (name.length > qualifier.length + 1 && name.endsWith(qualifier)) {
                name = name.removeSuffix(qualifier).trim()
                break
            }
        }
        name = stripCaseSuffix(name)
        if (name.isEmpty() || name.length < 2) return null
        return name
    }
}
