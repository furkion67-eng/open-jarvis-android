package com.openjarvis.commands

/**
 * Aggregates per-part Android SMS send results into one honest final result.
 *
 * Issue #5 acceptance rule: a message is reported as sent only when the
 * telephony stack confirms EVERY part of it. With multipart messages
 * ([android.telephony.SmsManager.sendMultipartTextMessage]) each part
 * reports its own resultCode; the first failure resolves the whole send as
 * failed and later parts are ignored (reported exactly once).
 *
 * Pure JVM — unit-testable without a device.
 */
class SmsSendResultAggregator(
    partCount: Int,
    private val onResolved: (Result<Unit>) -> Unit
) {
    private var remainingParts: Int = if (partCount < 1) 1 else partCount
    private var resolvedFlag: Boolean = false

    /** True once a final [Result] has been delivered to [onResolved]. */
    val isResolved: Boolean
        @Synchronized get() = resolvedFlag

    /**
     * Feeds one part's send result code
     * ([android.app.Activity.RESULT_OK] means the part was sent).
     */
    @Synchronized
    fun onPartResult(resultCode: Int) {
        if (resolvedFlag) return
        if (resultCode == android.app.Activity.RESULT_OK) {
            remainingParts -= 1
            if (remainingParts <= 0) {
                resolvedFlag = true
                onResolved(Result.success(Unit))
            }
        } else {
            resolvedFlag = true
            onResolved(
                Result.failure(
                    IllegalStateException("Android SMS gönderim sonucu: resultCode=$resultCode")
                )
            )
        }
    }
}
