package com.openjarvis.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Singleton bridge between the foreground assistant service and the UI.
 * The dashboard card collects [state] to show live Turkish status without
 * binding to the service, and posts updates from the service side.
 */
object AssistantServiceController {

    private val _state = MutableStateFlow<AssistantServiceState>(AssistantServiceState.NotRunning)
    val state: StateFlow<AssistantServiceState> = _state.asStateFlow()

    fun post(next: AssistantServiceState) {
        _state.value = next
    }

    /** Applies an event through the pure-JVM reducer and publishes the result. */
    fun dispatch(event: AssistantServiceEvent) {
        _state.value = AssistantServiceStateMachine.reduce(_state.value, event)
    }
}

/** Immutable UI-facing states of the assistant service. */
sealed class AssistantServiceState {
    /** Service not started (or fully stopped). */
    object NotRunning : AssistantServiceState()

    /** Service is initializing (foreground start, mic/recognizer setup). */
    object Starting : AssistantServiceState()

    /** Continuous wake-word listening loop is running. */
    object Listening : AssistantServiceState()

    /** Wake word was heard alone; the service is waiting for the command. */
    data class AwaitingCommand(val prompt: String) : AssistantServiceState()

    /** A command spoken after the wake word is being executed. */
    data class CommandDispatched(val command: String) : AssistantServiceState()

    /** Paused deterministically by the battery policy (reason shown to user). */
    data class Paused(val reason: String) : AssistantServiceState()

    /** Honest failure state (mic permission, no recognizer, init failure). */
    data class Error(val message: String) : AssistantServiceState()
}
