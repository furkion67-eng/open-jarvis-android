package com.openjarvis.graphify

/**
 * Pure-JVM fuzzy name matching used as a fallback when the exact-contact query
 * misses. Voice recognition output is noisy; callers ask for names heard from
 * speech, so an exact LIKE match is frequently not enough.
 */
object FuzzyMatcher {

    /** Maximum edit distance accepted for a full-name match. */
    const val MAX_FULL_NAME_DISTANCE = 2

    /** Maximum edit distance accepted for a single word (token) match. */
    const val MAX_TOKEN_DISTANCE = 1

    fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length

        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val substitutionCost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(
                    previous[j] + 1,
                    current[j - 1] + 1,
                    previous[j - 1] + substitutionCost
                )
            }
            // Every cell of the reused buffer is overwritten next round before
            // being read, so swapping the two references without copying is safe.
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }

    /**
     * True when [query] (a name heard from speech) plausibly refers to the same
     * person as [target] (a stored contact name), ignoring case and extra
     * whitespace: full-name edit distance <= [MAX_FULL_NAME_DISTANCE], or any
     * token pair within [MAX_TOKEN_DISTANCE].
     */
    fun isNameMatch(query: String, target: String): Boolean {
        val queryNormalized = query.trim().lowercase()
        val targetNormalized = target.trim().lowercase()
        if (queryNormalized.isEmpty() || targetNormalized.isEmpty()) return false
        if (queryNormalized == targetNormalized) return true
        if (editDistance(queryNormalized, targetNormalized) <= MAX_FULL_NAME_DISTANCE) return true
        val queryTokens = queryNormalized.split(WHITESPACE)
        val targetTokens = targetNormalized.split(WHITESPACE)
        return queryTokens.any { q -> targetTokens.any { t -> editDistance(q, t) <= MAX_TOKEN_DISTANCE } }
    }

    private val WHITESPACE = Regex("\\s+")
}
