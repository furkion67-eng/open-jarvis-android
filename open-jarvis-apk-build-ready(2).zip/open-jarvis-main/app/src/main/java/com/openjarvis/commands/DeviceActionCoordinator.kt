package com.openjarvis.commands

import com.openjarvis.agent.AgentState
import com.openjarvis.graphify.GraphifyRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Executes deterministically-routed Turkish commands (issue #5).
 *
 * Sensitive actions (SMS, calls) require explicit user confirmation; the
 * confirmation is rendered as [AgentState.AwaitingConfirmation] by the voice UI
 * and resolved through [confirmPending] / [cancelPending].
 */
class DeviceActionCoordinator(
    private val context: android.content.Context,
    private val graphifyRepo: GraphifyRepository,
    private val scope: CoroutineScope
) {

    private val executor = AndroidActionExecutor(context)

    private sealed class PendingDeviceAction {
        data class SmsAwaitingBody(val contactName: String?, val number: String) : PendingDeviceAction()
        data class SmsConfirmation(val contactName: String?, val number: String, val body: String) : PendingDeviceAction()
        data class CallConfirmation(val contactName: String?, val number: String) : PendingDeviceAction()
        data class WhatsAppAwaitingBody(val contactName: String?, val number: String) : PendingDeviceAction()
        data class WhatsAppConfirmation(val contactName: String?, val number: String, val body: String?) : PendingDeviceAction()
    }

    private var pending: PendingDeviceAction? = null

    /** True while a sensitive action waits for confirm/cancel or a message body. */
    fun hasPending(): Boolean = pending != null

    private fun awaitingBodyInput(): Boolean =
        pending is PendingDeviceAction.SmsAwaitingBody ||
            pending is PendingDeviceAction.WhatsAppAwaitingBody

    /**
     * Resolves a pending sensitive action with a spoken/text answer (issue #5).
     *
     * - "evet"/"onayla"/... confirms the pending SMS/call/WhatsApp action.
     * - "hayır"/"iptal"/... cancels it without doing anything.
     * - Any other free text supplies the requested message body while the
     *   coordinator is waiting for one.
     * - Free text during a confirmation is NOT treated as an answer; returns
     *   false so the caller can process it as a new command.
     */
    suspend fun handleWhilePending(command: String, setState: (AgentState) -> Unit): Boolean {
        if (pending == null) return false
        return when (VoiceDecision.parse(command)) {
            VoiceDecision.Decision.Confirm -> {
                if (awaitingBodyInput()) {
                    setState(AgentState.Error("Lütfen önce göndermek istediğiniz mesajı yazın."))
                } else {
                    confirmPending(setState)
                }
                true
            }
            VoiceDecision.Decision.Cancel -> {
                cancelPending(setState)
                true
            }
            VoiceDecision.Decision.None -> when (pending) {
                is PendingDeviceAction.SmsAwaitingBody, is PendingDeviceAction.WhatsAppAwaitingBody -> {
                    submitInput(command, setState)
                    true
                }
                else -> false
            }
        }
    }

    fun clearPending() {
        pending = null
    }

    suspend fun handle(routed: RoutedCommand, command: String, setState: (AgentState) -> Unit) {
        clearPending()
        when (routed) {
            is RoutedCommand.OpenApp -> handleOpenApp(routed, command, setState)
            is RoutedCommand.SendSms -> handleSms(routed, command, setState)
            is RoutedCommand.MakeCall -> handleCall(routed, command, setState)
            is RoutedCommand.WhatsAppMessage -> handleWhatsApp(routed, command, setState)
        }
    }

    private suspend fun handleOpenApp(routed: RoutedCommand.OpenApp, command: String, setState: (AgentState) -> Unit) {
        setState(AgentState.Running("${routed.appName} aranıyor..."))
        val packageName = executor.resolveAppPackage(routed.appName)
        if (packageName == null) {
            setState(AgentState.Error("Uygulama bulunamadı: ${routed.appName}"))
            logFailure(command, "app not found: ${routed.appName}")
            return
        }
        if (executor.launchApp(packageName)) {
            graphifyRepo.logAppOpened(packageName, routed.appName)
            setState(AgentState.Done("${routed.appName} açıldı."))
            graphifyRepo.logTask(command, "app opened: $packageName", "local-action", 0)
        } else {
            setState(AgentState.Error("${routed.appName} başlatılamadı."))
            logFailure(command, "app launch failed: $packageName")
        }
    }

    private suspend fun handleSms(routed: RoutedCommand.SendSms, command: String, setState: (AgentState) -> Unit) {
        setState(AgentState.Running("Alıcı çözümleniyor..."))
        val number = when {
            routed.phoneNumber != null -> routed.phoneNumber
            routed.contactName != null -> resolveContactNumber(routed.contactName, command, setState) ?: return
            else -> null
        }
        if (number == null) {
            setState(AgentState.Error("Alıcı belirsiz; hem kişi hem numara bulunamadı."))
            logFailure(command, "sms: no recipient")
            return
        }
        val body = routed.messageBody
        if (body.isNullOrBlank()) {
            pending = PendingDeviceAction.SmsAwaitingBody(routed.contactName, number)
            setState(
                AgentState.NeedsInput(
                    "${labelOf(routed.contactName, number)} için göndermek istediğiniz mesajı yazın."
                )
            )
            return
        }
        requestSmsConfirmation(routed.contactName, number, body, command, setState)
    }

    private suspend fun handleCall(routed: RoutedCommand.MakeCall, command: String, setState: (AgentState) -> Unit) {
        setState(AgentState.Running("Alıcı çözümleniyor..."))
        val number = when {
            routed.phoneNumber != null -> routed.phoneNumber
            routed.contactName != null -> resolveContactNumber(routed.contactName, command, setState) ?: return
            else -> null
        }
        if (number == null) {
            setState(AgentState.Error("Aranacak numara bulunamadı."))
            logFailure(command, "call: no recipient")
            return
        }
        pending = PendingDeviceAction.CallConfirmation(routed.contactName, number)
        setState(
            AgentState.AwaitingConfirmation(
                title = "Arama onayı",
                detail = "${labelOf(routed.contactName, number)} numarası aranacak: $number",
                confirmLabel = "Ara",
                cancelLabel = "İptal",
                actionTag = "make_call"
            )
        )
    }

    private suspend fun handleWhatsApp(routed: RoutedCommand.WhatsAppMessage, command: String, setState: (AgentState) -> Unit) {
        setState(AgentState.Running("Alıcı çözümleniyor..."))
        val number = when {
            routed.phoneNumber != null -> routed.phoneNumber
            routed.contactName != null -> resolveContactNumber(routed.contactName, command, setState) ?: return
            else -> null
        }
        if (number == null) {
            setState(AgentState.Error("WhatsApp alıcısı bulunamadı."))
            logFailure(command, "whatsapp: no recipient")
            return
        }
        if (routed.messageBody.isNullOrBlank()) {
            pending = PendingDeviceAction.WhatsAppAwaitingBody(routed.contactName, number)
            setState(AgentState.NeedsInput("${labelOf(routed.contactName, number)} için WhatsApp mesajını yazın."))
            return
        }
        pending = PendingDeviceAction.WhatsAppConfirmation(routed.contactName, number, routed.messageBody)
        setState(
            AgentState.AwaitingConfirmation(
                title = "WhatsApp onayı",
                detail = "${labelOf(routed.contactName, number)} ile sohbet açılacak. Mesaj: \"${routed.messageBody}\"",
                confirmLabel = "Sohbeti aç",
                cancelLabel = "İptal",
                actionTag = "whatsapp"
            )
        )
    }

    private suspend fun resolveContactNumber(
        name: String,
        command: String,
        setState: (AgentState) -> Unit
    ): String? {
        if (!executor.canReadContacts()) {
            setState(AgentState.Error("Rehber okuma izni verilmedi. Android uygulama ayarlarından Kişiler iznini açıp tekrar deneyin."))
            logFailure(command, "contacts permission missing")
            return null
        }
        return when (val resolution = executor.resolveContactNumber(name)) {
            is AndroidActionExecutor.ContactResolution.Exact -> resolution.number
            is AndroidActionExecutor.ContactResolution.Ambiguous -> {
                val names = resolution.candidates.joinToString(", ") { it.label }
                setState(AgentState.Error("Rehberde \"$name\" için birden fazla eşleşme var: $names. Lütfen tam adı söyleyin."))
                logFailure(command, "contacts ambiguous: $name")
                null
            }
            AndroidActionExecutor.ContactResolution.NotFound -> {
                setState(AgentState.Error("Rehberde \"$name\" bulunamadı."))
                logFailure(command, "contact not found: $name")
                null
            }
            AndroidActionExecutor.ContactResolution.PermissionMissing -> {
                setState(AgentState.Error("Rehber okuma izni verilmedi. Android uygulama ayarlarından Kişiler iznini açıp tekrar deneyin."))
                logFailure(command, "contacts permission missing")
                null
            }
        }
    }

    private suspend fun requestSmsConfirmation(
        contactName: String?,
        number: String,
        body: String,
        command: String,
        setState: (AgentState) -> Unit
    ) {
        pending = PendingDeviceAction.SmsConfirmation(contactName, number, body)
        setState(
            AgentState.AwaitingConfirmation(
                title = "SMS gönderme onayı",
                detail = "Alıcı: ${labelOf(contactName, number)} ($number)\nMesaj: $body",
                confirmLabel = "Gönder",
                cancelLabel = "İptal",
                actionTag = "send_sms"
            )
        )
    }

    suspend fun confirmPending(setState: (AgentState) -> Unit) {
        val action = pending
        if (action == null) {
            setState(AgentState.Idle)
            return
        }
        pending = null
        when (action) {
            is PendingDeviceAction.SmsConfirmation -> confirmSms(action, setState)
            is PendingDeviceAction.CallConfirmation -> {
                val direct = executor.canCallDirectly()
                val started = if (executor.placeCall(action.number, direct)) {
                    AgentState.Done(
                        if (direct) "Arama başlatıldı: ${labelOf(action.contactName, action.number)}."
                        else "Arama ekranı açıldı; aramayı oradan onaylayın."
                    )
                } else {
                    AgentState.Error("Arama başlatılamadı. (Numara: ${action.number})")
                }
                setState(started)
                graphifyRepo.logTask(
                    if (started is AgentState.Done) "call ok: ${action.contactName ?: action.number}" else "call failed",
                    if (started is AgentState.Done) "success" else "failed",
                    "local-action", 0
                )
            }
            is PendingDeviceAction.WhatsAppConfirmation -> {
                val opened = executor.openWhatsAppChat(action.number, action.body)
                setState(
                    if (opened) AgentState.Done("WhatsApp sohbeti açıldı; göndermek için oradaki gönder düğmesine dokunun.")
                    else AgentState.Error("WhatsApp sohbeti açılamadı (uygulama kurulu olmayabilir).")
                )
                graphifyRepo.logTask("whatsapp chat ${action.contactName ?: action.number}", if (opened) "success" else "failed", "local-action", 0)
            }
            else -> setState(AgentState.Idle)
        }
    }

    private suspend fun confirmSms(action: PendingDeviceAction.SmsConfirmation, setState: (AgentState) -> Unit) {
        if (executor.canSendSmsDirectly()) {
            setState(AgentState.Running("SMS gönderiliyor..."))
            executor.sendSms(action.number, action.body) { result ->
                scope.launch(Dispatchers.IO) {
                    result.fold(
                        onSuccess = {
                            setState(AgentState.Done("SMS gönderildi: ${labelOf(action.contactName, action.number)}."))
                            graphifyRepo.logTask("sms to ${action.contactName ?: action.number}", "success", "local-action", 0)
                        },
                        onFailure = { error ->
                            setState(AgentState.Error("SMS gönderilemedi: ${error.message ?: "bilinmeyen hata"}"))
                            graphifyRepo.logTask("sms to ${action.contactName ?: action.number}", "failed: ${error.message}", "local-action", 0)
                        }
                    )
                }
            }
        } else {
            val opened = executor.openSmsApp(action.number, action.body)
            setState(
                if (opened) AgentState.Done("SMS uygulaması açıldı; mesaj hazır. Göndermek için oradaki gönder düğmesine dokunun.")
                else AgentState.Error("SMS uygulaması açılamadı.")
            )
            graphifyRepo.logTask(
                "sms to ${action.contactName ?: action.number}",
                if (opened) "sms app opened (no SEND_SMS permission)" else "failed", "local-action", 0
            )
        }
    }

    suspend fun cancelPending(setState: (AgentState) -> Unit) {
        pending = null
        setState(AgentState.Done("İptal edildi."))
    }

    suspend fun submitInput(text: String, setState: (AgentState) -> Unit) {
        val body = text.trim()
        if (body.isEmpty()) {
            setState(AgentState.Error("Boş mesaj gönderilemez."))
            return
        }
        when (val action = pending) {
            is PendingDeviceAction.SmsAwaitingBody -> requestSmsConfirmation(action.contactName, action.number, body, "sms", setState)
            is PendingDeviceAction.WhatsAppAwaitingBody -> {
                pending = PendingDeviceAction.WhatsAppConfirmation(action.contactName, action.number, body)
                setState(
                    AgentState.AwaitingConfirmation(
                        title = "WhatsApp onayı",
                        detail = "${labelOf(action.contactName, action.number)} ile sohbet açılacak. Mesaj: \"$body\"",
                        confirmLabel = "Sohbeti aç",
                        cancelLabel = "İptal",
                        actionTag = "whatsapp"
                    )
                )
            }
            is PendingDeviceAction.SmsConfirmation -> requestSmsConfirmation(action.contactName, action.number, body, "sms", setState)
            else -> setState(AgentState.Error("Şu anda bekleyen bir mesaj yok. Önce alıcıyı belirtin."))
        }
    }

    private fun labelOf(contactName: String?, number: String): String = contactName ?: number

    private suspend fun logFailure(command: String, reason: String) {
        graphifyRepo.logTask(command, "failed: $reason", "local-action", 0)
    }
}
