package com.openjarvis.graphify

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.openjarvis.graphify.nodes.*
import com.openjarvis.intelligence.AppIntelligenceEntity
import com.openjarvis.intelligence.AppIntelligenceDao

@Database(
    entities = [
        AppNode::class,
        TaskNode::class,
        ContactNode::class,
        PatternNode::class,
        ProviderNode::class,
        EdgeEntity::class,
        AppIntelligenceEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class GraphifyDB : RoomDatabase() {
    abstract fun appNodeDao(): AppNodeDao
    abstract fun taskNodeDao(): TaskNodeDao
    abstract fun contactNodeDao(): ContactNodeDao
    abstract fun patternNodeDao(): PatternNodeDao
    abstract fun providerNodeDao(): ProviderNodeDao
    abstract fun edgeDao(): EdgeDao
    abstract fun appIntelligenceDao(): AppIntelligenceDao
    
    companion object {
        private const val DB_NAME = "graphify.db"

        @Volatile
        private var INSTANCE: GraphifyDB? = null
        
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS app_intelligence (
                        packageName TEXT PRIMARY KEY NOT NULL,
                        appName TEXT NOT NULL,
                        category TEXT NOT NULL,
                        capabilities TEXT NOT NULL,
                        trustScore REAL NOT NULL DEFAULT 0.5,
                        lastAnalyzed INTEGER NOT NULL,
                        isAIApp INTEGER NOT NULL DEFAULT 0,
                        aiMeta TEXT
                    )
                """.trimIndent())
                
                db.execSQL("CREATE INDEX IF NOT EXISTS index_app_intel_category ON app_intelligence(category)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_app_intel_ai ON app_intelligence(isAIApp)")
            }
        }
        
        fun getInstance(context: Context): GraphifyDB {
            return INSTANCE ?: synchronized(this) {
                // Issue #3: a graphify.db left by an older build (schema version 1)
                // or a corrupt file cannot be migrated to the current schema and
                // would crash the app on the first Room query. Back it up (rename,
                // never delete) so Room can create a fresh, current-schema database.
                try {
                    val renamed = GraphifyDbRecovery.recoverUnmigratableDatabase(
                        context.getDatabasePath(DB_NAME)
                    )
                    if (renamed.isNotEmpty()) {
                        android.util.Log.w(
                            "GraphifyDB",
                            "Backed up un-migratable graphify.db: " +
                                renamed.joinToString(", ") { it.name }
                        )
                    }
                } catch (t: Throwable) {
                    android.util.Log.w(
                        "GraphifyDB",
                        "Database recovery check failed; leaving database untouched",
                        t
                    )
                }
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GraphifyDB::class.java,
                    DB_NAME
                )
                    .addMigrations(MIGRATION_2_3)
                    .build()
                INSTANCE = instance
                instance
            }
        }
        
        fun resetForTesting() {
            INSTANCE = null
        }
    }
}