package com.openjarvis.commands

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.openjarvis.agent.AgentState
import com.openjarvis.graphify.GraphifyRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * On-device verification of the issue #5 confirmation gate and permission
 * paths (device-side, not JVM-simulated):
 *
 * 1. A routed SMS/call command NEVER executes while unconfirmed; it must first
 *    surface AgentState.AwaitingConfirmation.
 * 2. A spoken "iptal" (cancel) resolves the pending action with Done("İptal
 *    edildi") and nothing is sent/dialled.
 * 3. Free text during a confirmation is not treated as an answer.
 * 4. Without READ_CONTACTS, a contact-based command reports the Turkish
 *    permission error instead of crashing.
 * 5. Confirming an SMS without SEND_SMS never claims the message was sent
 *    (issue #5 honesty rule) — it falls back to the prefilled SMS app.
 *
 * Instrumented tests do not hold READ_CONTACTS/SEND_SMS by default, so the
 * permission-missing paths here run against the real OS permission state.
 */
@RunWith(AndroidJUnit4::class)
class ConfirmationGatingInstrumentedTest {

    private fun newCoordinator(): DeviceActionCoordinator {
        val context = InstrumentationRegistry.getInstrumentation()
            .targetContext.applicationContext as Context
        val repo = GraphifyRepository(context)
        val scope = CoroutineScope(Dispatchers.Main)
        return DeviceActionCoordinator(context, repo, scope)
    }

    @Test
    fun sendSmsConfirmationRequiresExplicitConfirmBeforeSending() = runBlocking {
        val coordinator = newCoordinator()
        val states = mutableListOf<AgentState>()
        coordinator.handle(
            RoutedCommand.SendSms(contactName = null, phoneNumber = "0533 111 22 33", messageBody = "merhaba"),
            "0533 111 22 33 numarasına merhaba gönder"
        ) { states.add(it) }

        val state = states.last()
        assertTrue("expected AwaitingConfirmation, got $state", state is AgentState.AwaitingConfirmation)
        state as AgentState.AwaitingConfirmation
        assertEquals("send_sms", state.actionTag)
        assertTrue(state.detail.contains("0533 111 22 33"))
        assertTrue(state.detail.contains("merhaba"))
    }

    @Test
    fun spokenCancelResolvesPendingSmsWithoutSendingAnything() = runBlocking {
        val coordinator = newCoordinator()
        val states = mutableListOf<AgentState>()
        coordinator.handle(
            RoutedCommand.SendSms(contactName = null, phoneNumber = "0533 111 22 33", messageBody = "merhaba"),
            "sms"
        ) { states.add(it) }
        assertTrue(coordinator.hasPending())

        val handled = coordinator.handleWhilePending("iptal") { states.add(it) }
        assertTrue("spoken cancel should be handled while pending", handled)
        assertFalse(coordinator.hasPending())
        val state = states.last()
        assertTrue("expected Done, got $state", state is AgentState.Done)
        assertEquals("İptal edildi.", (state as AgentState.Done).result)
    }

    @Test
    fun missingBodyWaitsForUserInputThenConfirmationThenFreeTextIsNotAnAnswer() = runBlocking {
        val coordinator = newCoordinator()
        val states = mutableListOf<AgentState>()
        coordinator.handle(
            RoutedCommand.SendSms(contactName = null, phoneNumber = "0533 111 22 33", messageBody = null),
            "sms"
        ) { states.add(it) }
        assertTrue("expected NeedsInput, got ${states.last()}", states.last() is AgentState.NeedsInput)

        // Spoken body while awaiting input is accepted and moves to confirmation.
        val handledBody = coordinator.handleWhilePending("projeyi bitirdim yarın görüşürüz") { states.add(it) }
        assertTrue(handledBody)
        val confirm = states.last()
        assertTrue("expected AwaitingConfirmation, got $confirm", confirm is AgentState.AwaitingConfirmation)
        assertTrue((confirm as AgentState.AwaitingConfirmation).detail.contains("projeyi bitirdim"))

        // Free text during confirmation is NOT an answer and is NOT executed.
        val handledFreeText = coordinator.handleWhilePending("selam naber") { states.add(it) }
        assertFalse("free text during confirmation must fall through to the router", handledFreeText)
        assertTrue(coordinator.hasPending())

        coordinator.cancelPending { }
        assertFalse(coordinator.hasPending())
    }

    @Test
    fun missingContactsPermissionReportsTurkishErrorInsteadOfCrashing() = runBlocking {
        val coordinator = newCoordinator()
        val states = mutableListOf<AgentState>()
        coordinator.handle(
            RoutedCommand.SendSms(contactName = "Ayşe Yılmaz", phoneNumber = null, messageBody = "merhaba"),
            "ayşe yılmaza merhaba gönder"
        ) { states.add(it) }

        val state = states.last()
        assertTrue("expected Error, got $state", state is AgentState.Error)
        assertTrue(
            "expected permission error, got ${(state as AgentState.Error).message}",
            state.message.contains("Rehber okuma izni verilmedi")
        )
        assertFalse(coordinator.hasPending())
    }

    @Test
    fun confirmingSmsWithoutSendSmsPermissionNeverClaimsSent() = runBlocking {
        val coordinator = newCoordinator()
        val states = mutableListOf<AgentState>()
        coordinator.handle(
            RoutedCommand.SendSms(contactName = null, phoneNumber = "0533 111 22 33", messageBody = "merhaba"),
            "sms"
        ) { states.add(it) }

        coordinator.confirmPending { states.add(it) }
        val state = states.last()
        assertTrue("expected Done/Error, got $state", state is AgentState.Done || state is AgentState.Error)
        val message = when (state) {
            is AgentState.Done -> state.result
            is AgentState.Error -> state.message
            else -> ""
        }
        assertFalse(
            "without SEND_SMS the app must never claim the SMS was sent, got: $message",
            message.contains("SMS gönderildi")
        )
    }

    @Test
    fun callCommandWaitsForConfirmationAndCancelDoesNothing() = runBlocking {
        val coordinator = newCoordinator()
        val states = mutableListOf<AgentState>()
        coordinator.handle(
            RoutedCommand.MakeCall(contactName = null, phoneNumber = "0533 111 22 33"),
            "0533 111 22 33 numarasını ara"
        ) { states.add(it) }

        val state = states.last()
        assertTrue("expected AwaitingConfirmation, got $state", state is AgentState.AwaitingConfirmation)
        assertEquals("make_call", (state as AgentState.AwaitingConfirmation).actionTag)
        assertTrue(coordinator.hasPending())

        coordinator.cancelPending { states.add(it) }
        assertFalse(coordinator.hasPending())
        assertEquals("İptal edildi.", (states.last() as AgentState.Done).result)
    }
}
