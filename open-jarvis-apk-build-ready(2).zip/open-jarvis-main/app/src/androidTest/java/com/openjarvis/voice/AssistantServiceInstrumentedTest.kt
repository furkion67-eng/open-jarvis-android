package com.openjarvis.voice

import android.Manifest
import android.app.Instrumentation
import android.content.Intent
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.openjarvis.ui.MainActivity
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Device-level lifecycle validation for the foreground assistant service
 * (issue #7). Asserts real state-machine transitions on an Android 13
 * emulator and that no failure path crashes the host process.
 */
@RunWith(AndroidJUnit4::class)
class AssistantServiceInstrumentedTest {

    private val instrumentation: Instrumentation = InstrumentationRegistry.getInstrumentation()

    @Before
    fun grantMicrophone() {
        instrumentation.uiAutomation.grantRuntimePermission(
            instrumentation.targetContext.packageName,
            Manifest.permission.RECORD_AUDIO
        )
    }

    @After
    fun restoreMicrophone() {
        instrumentation.uiAutomation.grantRuntimePermission(
            instrumentation.targetContext.packageName,
            Manifest.permission.RECORD_AUDIO
        )
    }

    /**
     * Brings the app to the foreground (required for a while-in-use
     * microphone foreground service on Android 13) and starts the service.
     */
    private fun startServiceInForeground() {
        val target = instrumentation.targetContext
        instrumentation.startActivitySync(
            Intent(target, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        instrumentation.runOnMainSync { AssistantService.start(target) }
    }

    private fun stopServiceFromForeground() {
        val target = instrumentation.targetContext
        instrumentation.runOnMainSync { AssistantService.stop(target) }
    }

    private suspend fun awaitResolvedState(): AssistantServiceState =
        withTimeoutOrNull(15_000) {
            while (AssistantServiceController.state.value == AssistantServiceState.Starting) {
                instrumentation.waitForIdleSync()
                Thread.sleep(100)
            }
            AssistantServiceController.state.value
        } ?: AssistantServiceController.state.value

    @Test
    fun serviceStartReportsHonestResolvedStateWithoutCrashing() = runBlocking {
        startServiceInForeground()
        val state = awaitResolvedState()

        // On a device without a recognition service or without battery headroom
        // the service must report an honest Error/Paused state — never NotRunning
        // silently and never crash.
        assertTrue(
            "Unexpected state: $state",
            state is AssistantServiceState.Listening ||
                state is AssistantServiceState.AwaitingCommand ||
                state is AssistantServiceState.CommandDispatched ||
                state is AssistantServiceState.Error ||
                state is AssistantServiceState.Paused
        )
        // Ensure the process is still alive and responsive.
        instrumentation.waitForIdleSync()
    }

    @Test
    fun stopActionTransitionsServiceToNotRunning() = runBlocking {
        startServiceInForeground()
        awaitResolvedState()

        stopServiceFromForeground()
        val stopped = withTimeoutOrNull(10_000) {
            while (AssistantServiceController.state.value != AssistantServiceState.NotRunning) {
                Thread.sleep(100)
            }
            true
        }
        assertEquals(true, stopped)
        assertEquals(AssistantServiceState.NotRunning, AssistantServiceController.state.value)
    }

    @Test
    fun missingMicrophonePermissionYieldsErrorStateNotCrash() = runBlocking {
        instrumentation.uiAutomation.revokeRuntimePermission(
            instrumentation.targetContext.packageName,
            Manifest.permission.RECORD_AUDIO
        )
        AssistantServiceController.post(AssistantServiceState.NotRunning)
        startServiceInForeground()
        val state = awaitResolvedState()

        assertTrue("Expected honest Error, got: $state", state is AssistantServiceState.Error)
        assertTrue(
            "Error must mention the microphone permission",
            (state as AssistantServiceState.Error).message.contains("Mikrofon izni")
        )
        assertNotEquals(AssistantServiceState.NotRunning, AssistantServiceController.state.value)
    }
}
