package com.openjarvis.graphify

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.openjarvis.graphify.nodes.TaskNode
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * End-to-end reproduction of the issue #3 device state on a real Android runtime:
 * a graphify.db left by an older build (schema version 1) must be backed up and
 * must NOT crash the app with "A migration from 1 to 3 was required but not found".
 */
@RunWith(AndroidJUnit4::class)
class GraphifyDbRecoveryInstrumentedTest {

    private fun cleanDatabasesDir(context: Context) {
        context.deleteDatabase("graphify.db")
        context.getDatabasePath("graphify.db").parentFile
            ?.listFiles()
            ?.filter { it.name.startsWith("graphify.db.") && it.name.contains("unmigratable") }
            ?.forEach { it.delete() }
    }

    private fun plantLegacyV1Database(context: Context) {
        context.getDatabasePath("graphify.db").parentFile?.mkdirs()
        context.openOrCreateDatabase("graphify.db", Context.MODE_PRIVATE, null).use { db ->
            db.execSQL("CREATE TABLE IF NOT EXISTS legacy_marker (id INTEGER PRIMARY KEY)")
            db.version = 1
        }
    }

    @Test
    fun legacyDatabaseIsBackedUpAndRoomCreatesFreshSchema() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        cleanDatabasesDir(context)
        plantLegacyV1Database(context)

        GraphifyDB.resetForTesting()

        val repo = GraphifyRepository(context)
        val tasks = runBlocking { repo.getRecentTasks(10) }

        // The first Room query would throw IllegalStateException without the fix.
        assertNotNull(tasks)
        assertTrue(tasks.isEmpty())

        val databasesDir = context.getDatabasePath("graphify.db").parentFile
        val backup = databasesDir?.listFiles()?.firstOrNull {
            it.name.startsWith("graphify.db.unmigratable-")
        }
        assertNotNull("Legacy database must be renamed, not deleted", backup)
        assertTrue("Backup must retain data", backup!!.length() > 0)

        // A fresh, current-schema database now exists and works.
        runBlocking { repo.logTask("smoke: recovery", "ok", "test", 0) }
        val after = runBlocking { repo.getRecentTasks(10) }
        assertEquals(1, after.size)
        assertTrue(
            "Room must have created a fresh graphify.db",
            databasesDir.listFiles()!!.any { it.name == "graphify.db" }
        )
    }
}
