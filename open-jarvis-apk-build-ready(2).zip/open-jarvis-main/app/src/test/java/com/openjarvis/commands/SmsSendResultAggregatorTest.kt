package com.openjarvis.commands

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * JVM tests for the honest multipart SMS result aggregation (issue #5):
 * success may be reported only when every part is confirmed by the
 * telephony stack; the first failure wins and the final result is
 * delivered exactly once.
 */
class SmsSendResultAggregatorTest {

    private class Collector {
        var calls = 0
        var success = false
        var error: Throwable? = null
        fun onResult(result: Result<Unit>) {
            calls += 1
            result.fold(
                onSuccess = { success = true },
                onFailure = { error = it }
            )
        }
    }

    @Test
    fun singleConfirmedPartResolvesWithSuccess() {
        val collector = Collector()
        val aggregator = SmsSendResultAggregator(1, collector::onResult)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        assertTrue(aggregator.isResolved)
        assertEquals(1, collector.calls)
        assertTrue(collector.success)
    }

    @Test
    fun successReportedOnlyAfterEveryPartIsConfirmed() {
        val collector = Collector()
        val aggregator = SmsSendResultAggregator(3, collector::onResult)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        assertFalse("must not report success while parts are unconfirmed", aggregator.isResolved)
        assertEquals(0, collector.calls)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        assertFalse(aggregator.isResolved)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        assertTrue(aggregator.isResolved)
        assertEquals(1, collector.calls)
        assertTrue(collector.success)
    }

    @Test
    fun firstFailingPartResolvesAsFailureAndIgnoresLaterParts() {
        val collector = Collector()
        val aggregator = SmsSendResultAggregator(2, collector::onResult)
        aggregator.onPartResult(137)
        assertTrue(aggregator.isResolved)
        assertEquals(1, collector.calls)
        assertFalse(collector.success)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        assertEquals("result must be delivered exactly once", 1, collector.calls)
        assertEquals(137.toLong(), collector.error?.message?.let { Regex("resultCode=(\\d+)").find(it)?.groupValues?.get(1)?.toLong() })
    }

    @Test
    fun failureAfterSomeConfirmedPartsStillReportsFailure() {
        val collector = Collector()
        val aggregator = SmsSendResultAggregator(3, collector::onResult)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        assertFalse(aggregator.isResolved)
        aggregator.onPartResult(23)
        assertTrue(aggregator.isResolved)
        assertEquals(1, collector.calls)
        assertFalse(collector.success)
        assertTrue(collector.error?.message?.contains("resultCode=23") == true)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        assertEquals("result must be delivered exactly once", 1, collector.calls)
    }

    @Test
    fun failureMessageContainsTelephonyResultCode() {
        val collector = Collector()
        val aggregator = SmsSendResultAggregator(1, collector::onResult)
        aggregator.onPartResult(5)
        assertEquals(1, collector.calls)
        assertTrue(collector.error?.message?.contains("resultCode=5") == true)
    }

    @Test
    fun zeroPartFallbackStillResolvesFromOneResult() {
        val collector = Collector()
        val aggregator = SmsSendResultAggregator(0, collector::onResult)
        aggregator.onPartResult(android.app.Activity.RESULT_OK)
        assertTrue(aggregator.isResolved)
        assertEquals(1, collector.calls)
        assertTrue(collector.success)
    }
}
