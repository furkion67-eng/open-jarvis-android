package com.openjarvis.graphify

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FuzzyMatcherTest {

    @Test
    fun exactMatchAfterNormalization() {
        assertTrue(FuzzyMatcher.isNameMatch(" john doe ", "John Doe"))
    }

    @Test
    fun transpositionWithinDistanceTwoMatches() {
        assertTrue(FuzzyMatcher.isNameMatch("Jhon Doe", "John Doe"))
        assertTrue(FuzzyMatcher.isNameMatch("Jon Doe", "John Doe"))
    }

    @Test
    fun singleTokenTypoMatches() {
        assertTrue(FuzzyMatcher.isNameMatch("Ahmet", "Ahmet Yılmaz"))
        assertTrue(FuzzyMatcher.isNameMatch("yilmaz", "Ahmet Yılmaz"))
    }

    @Test
    fun unrelatedNamesDoNotMatch() {
        assertFalse(FuzzyMatcher.isNameMatch("Zeynep Kaya", "John Doe"))
        assertFalse(FuzzyMatcher.isNameMatch("", "John Doe"))
    }

    @Test
    fun editDistanceIsSymmetricAndExact() {
        org.junit.Assert.assertEquals(0, FuzzyMatcher.editDistance("abc", "abc"))
        org.junit.Assert.assertEquals(1, FuzzyMatcher.editDistance("abc", "abd"))
        org.junit.Assert.assertEquals(3, FuzzyMatcher.editDistance("kitten", "sitting"))
        org.junit.Assert.assertEquals(
            FuzzyMatcher.editDistance("kitten", "sitting"),
            FuzzyMatcher.editDistance("sitting", "kitten")
        )
    }
}
