package com.openjarvis.bridge

import org.junit.Test
import org.junit.Assert.*

/**
 * JVM unit tests for the bridge socket wire protocol.
 * No Android runtime dependency: exercises SocketProtocol directly.
 */
class SocketProtocolTest {

    @Test
    fun `parseRequest with valid JSON returns command and requestId`() {
        val result = SocketProtocol.parseRequest("""{"cmd":"open chrome","requestId":"abc123"}""")

        assertNotNull(result)
        assertEquals("abc123", result?.first)
        assertEquals("open chrome", result?.second)
    }

    @Test
    fun `parseRequest with missing cmd returns null`() {
        assertNull(SocketProtocol.parseRequest("""{"requestId":"abc123"}"""))
    }

    @Test
    fun `parseRequest with invalid JSON returns null`() {
        assertNull(SocketProtocol.parseRequest("not json"))
    }

    @Test
    fun `parseRequest with empty request uses empty string`() {
        val result = SocketProtocol.parseRequest("""{"cmd":"status"}""")

        assertNotNull(result)
        assertEquals("", result?.first)
        assertEquals("status", result?.second)
    }

    @Test
    fun `parseRequest rejects oversized commands`() {
        val oversized = "x".repeat(SocketProtocol.MAX_COMMAND_LENGTH + 1)
        assertNull("Oversized command should be rejected", SocketProtocol.parseRequest(
            """{"cmd":"$oversized","requestId":"big"}"""
        ))
    }

    @Test
    fun `escapeJson escapes special characters`() {
        val escaped = SocketProtocol.escapeJson("hello\nworld\"test\tvalue")

        assertTrue(escaped.contains("\\n"))
        assertTrue(escaped.contains("\\\""))
        assertTrue(escaped.contains("\\t"))
    }

    @Test
    fun `escapeJson roundtrip through JSONObject`() {
        val input = "quote\" backslash\\ newline\n tab\t"
        val json = """{"result":"${SocketProtocol.escapeJson(input)}"}"""

        assertEquals(input, org.json.JSONObject(json).optString("result"))
    }

    @Test
    fun `createErrorResponse formats correctly`() {
        val response = SocketProtocol.createErrorResponse("req123", "test error")

        assertTrue(response.contains("req123"))
        assertTrue(response.contains("error"))
        assertTrue(response.contains("test error"))
    }

    @Test
    fun `malformed JSON handled gracefully`() {
        val malformedInputs = listOf("", "{", "{\"cmd\":", "null", "[][]")

        for (input in malformedInputs) {
            assertNull("Should return null for: $input", SocketProtocol.parseRequest(input))
        }
    }

    @Test
    fun `requestId roundtrip preserved`() {
        val testIds = listOf("abc123", "xyz789", "test-id-001", "")

        for (id in testIds) {
            val json = if (id.isEmpty()) {
                """{"cmd":"test"}"""
            } else {
                """{"cmd":"test","requestId":"$id"}"""
            }

            val result = SocketProtocol.parseRequest(json)
            assertNotNull("Failed for id: $id", result)
            assertEquals(id, result?.first)
        }
    }
}
