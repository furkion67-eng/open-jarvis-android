package com.openjarvis.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeWordDetectorTest {

    @Test
    fun wakeWordAloneReturnsWakeOnly() {
        assertEquals(Detection.WakeOnly, WakeWordDetector.detect("Jarvis"))
    }

    @Test
    fun wakeWordWithTurkishSuffixReturnsCommand() {
        val detection = WakeWordDetector.detect("Jarvis, Sıla'ya SMS gönder") as Detection.Command
        assertEquals("sila ya sms gönder", detection.text)
    }

    @Test
    fun lowercaseTextIsMatched() {
        assertTrue(WakeWordDetector.detect("jarvis yeni görev aç") is Detection.Command)
    }

    @Test
    fun misrecognizedVariantWithinEditDistanceTriggers() {
        assertTrue(WakeWordDetector.detect("jervis saat kur") is Detection.Command)
    }

    @Test
    fun unrelatedSpeechIsIgnored() {
        assertEquals(Detection.None, WakeWordDetector.detect("bugün hava nasıl"))
    }

    @Test
    fun nullOrBlankTextIsIgnored() {
        assertEquals(Detection.None, WakeWordDetector.detect(null))
        assertEquals(Detection.None, WakeWordDetector.detect("   "))
    }

    @Test
    fun wakeWordInMiddleStillExtractsFollowingCommand() {
        val detection = WakeWordDetector.detect("hey jarvis whatsapp aç") as Detection.Command
        assertEquals("whatsapp aç", detection.text)
    }

    @Test
    fun emptyCommandAfterWakeWordStopsAtWakeOnly() {
        assertEquals(Detection.WakeOnly, WakeWordDetector.detect("Jarvis..."))
    }

    @Test
    fun levenshteinBasics() {
        assertEquals(0, WakeWordDetector.levenshtein("jarvis", "jarvis"))
        assertEquals(1, WakeWordDetector.levenshtein("jervis", "jarvis"))
        assertEquals(2, WakeWordDetector.levenshtein("servis", "jarvis"))
        assertEquals(1, WakeWordDetector.levenshtein("jervis", "servis"))
    }

    @Test
    fun wakeWordPrefixMatchRejectsFarTokens() {
        assertTrue(WakeWordDetector.matchesWakeWord("jarvis"))
        assertTrue(WakeWordDetector.matchesWakeWord("jervis"))
        assertEquals(false, WakeWordDetector.matchesWakeWord("servis"))
    }
}
