package com.openjarvis.graphify

import org.junit.Test
import org.junit.Assert.*
import java.io.File

/**
 * JVM unit tests for the graphify.db startup recovery (issue #3):
 * an un-migratable legacy database must be renamed (never deleted) so the
 * app can no longer crash with "A migration from 1 to 3 was required but not found".
 */
class GraphifyDbRecoveryTest {

    private fun sqliteHeader(version: Int, validMagic: Boolean = true): ByteArray {
        val header = ByteArray(100)
        if (validMagic) {
            "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII).copyInto(header)
        }
        header[44] = ((version shr 24) and 0xFF).toByte()
        header[45] = ((version shr 16) and 0xFF).toByte()
        header[46] = ((version shr 8) and 0xFF).toByte()
        header[47] = (version and 0xFF).toByte()
        return header
    }

    private fun newTempDir(): File = createTempDir(prefix = "graphify-recovery-test")

    @Test
    fun `current schema v3 is not flagged for recovery`() {
        assertFalse(GraphifyDbRecovery.shouldRecoverFromHeader(sqliteHeader(3)))
    }

    @Test
    fun `schema v2 is migratable and not flagged for recovery`() {
        assertFalse(GraphifyDbRecovery.shouldRecoverFromHeader(sqliteHeader(2)))
    }

    @Test
    fun `legacy v1 database is flagged for recovery`() {
        assertTrue(GraphifyDbRecovery.shouldRecoverFromHeader(sqliteHeader(1)))
    }

    @Test
    fun `future schema version is flagged for recovery`() {
        assertTrue(GraphifyDbRecovery.shouldRecoverFromHeader(sqliteHeader(4)))
    }

    @Test
    fun `corrupt magic bytes are flagged for recovery`() {
        assertTrue(GraphifyDbRecovery.shouldRecoverFromHeader(sqliteHeader(3, validMagic = false)))
    }

    @Test
    fun `truncated header is flagged for recovery`() {
        assertTrue(GraphifyDbRecovery.shouldRecoverFromHeader(ByteArray(40)))
    }

    @Test
    fun `legacy v1 database file is backed up with contents intact`() {
        val dir = newTempDir()
        try {
            val db = File(dir, "graphify.db")
            db.writeBytes(sqliteHeader(1) + ByteArray(200) { 0x42 })

            val renamed = GraphifyDbRecovery.recoverUnmigratableDatabase(db, now = 123L)

            assertEquals(1, renamed.size)
            assertFalse("Original db file should be gone after rename", db.exists())
            assertEquals("graphify.db.unmigratable-123", renamed[0].name)
            assertTrue("Renamed backup must keep the original bytes", renamed[0].length() > 200)
            assertTrue(renamed[0].readBytes().endsWith(ByteArray(200) { 0x42 }))
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `current v3 database file is left untouched`() {
        val dir = newTempDir()
        try {
            val db = File(dir, "graphify.db")
            db.writeBytes(sqliteHeader(3))

            val renamed = GraphifyDbRecovery.recoverUnmigratableDatabase(db, now = 1L)

            assertTrue(renamed.isEmpty())
            assertTrue("Migratable database must not be touched", db.exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `wal and journal sidecars are backed up together`() {
        val dir = newTempDir()
        try {
            val db = File(dir, "graphify.db")
            db.writeBytes(sqliteHeader(1))
            File(dir, "graphify.db-wal").writeBytes(byteArrayOf(1, 2, 3))
            File(dir, "graphify.db-shm").writeBytes(byteArrayOf(4))
            File(dir, "graphify.db-journal").writeBytes(byteArrayOf(5))

            val renamed = GraphifyDbRecovery.recoverUnmigratableDatabase(db, now = 7L)

            assertEquals(4, renamed.size)
            assertTrue(renamed.all { it.name.endsWith(".unmigratable-7") })
            assertTrue(File(dir, "graphify.db.unmigratable-7").exists())
            assertTrue(File(dir, "graphify.db-wal.unmigratable-7").exists())
            assertTrue(File(dir, "graphify.db-shm.unmigratable-7").exists())
            assertTrue(File(dir, "graphify.db-journal.unmigratable-7").exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `previously backed up files are never renamed again`() {
        val dir = newTempDir()
        try {
            val db = File(dir, "graphify.db")
            db.writeBytes(sqliteHeader(1))
            File(dir, "graphify.db.unmigratable-1").writeBytes(byteArrayOf(9))

            val renamed = GraphifyDbRecovery.recoverUnmigratableDatabase(db, now = 2L)

            assertEquals(1, renamed.size)
            assertTrue(File(dir, "graphify.db.unmigratable-1").exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `missing database file is a no-op`() {
        val dir = newTempDir()
        try {
            val renamed = GraphifyDbRecovery.recoverUnmigratableDatabase(File(dir, "graphify.db"))

            assertTrue(renamed.isEmpty())
        } finally {
            dir.deleteRecursively()
        }
    }
}
