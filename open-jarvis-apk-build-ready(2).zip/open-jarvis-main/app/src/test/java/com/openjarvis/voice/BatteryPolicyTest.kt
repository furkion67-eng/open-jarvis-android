package com.openjarvis.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BatteryPolicyTest {

    @Test
    fun sufficientBatteryRuns() {
        assertEquals(BatteryDecision.Run, BatteryPolicy.decide(80, isCharging = false))
    }

    @Test
    fun chargingAlwaysRunsEvenAtZero() {
        assertEquals(BatteryDecision.Run, BatteryPolicy.decide(0, isCharging = true))
    }

    @Test
    fun lowBatteryNotChargingPausesWithTurkishReason() {
        val decision = BatteryPolicy.decide(10, isCharging = false) as BatteryDecision.Pause
        assertTrue(decision.reason.contains("Pil seviyesi düşük"))
        assertTrue(decision.reason.contains("%10"))
    }

    @Test
    fun boundaryLevelAtMinRuns() {
        assertEquals(BatteryDecision.Run, BatteryPolicy.decide(BatteryPolicy.DEFAULT_MIN_LEVEL, isCharging = false))
    }

    @Test
    fun customThresholdIsRespected() {
        assertEquals(BatteryDecision.Run, BatteryPolicy.decide(40, isCharging = false, minLevelPercent = 40))
        assertTrue(BatteryPolicy.decide(39, isCharging = false, minLevelPercent = 40) is BatteryDecision.Pause)
    }

    @Test
    fun outOfRangeValuesAreCoerced() {
        assertEquals(BatteryDecision.Run, BatteryPolicy.decide(150, isCharging = false))
        assertTrue(BatteryPolicy.decide(-5, isCharging = false) is BatteryDecision.Pause)
    }
}
