package com.openjarvis.commands

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Issue #5 acceptance: Turkish utterances such as "Sıla'ya SMS gönder" must be
 * routed deterministically to the SMS action instead of reaching the LLM.
 */
class TurkishCommandRouterTest {

    private fun route(command: String) = TurkishCommandRouter.route(command)

    // ---- SMS ----------------------------------------------------------------

    @Test
    fun smsSendWithoutBodyRoutesToSms() {
        val routed = route("Sıla'ya SMS gönder")
        assertEquals("Sıla", (routed as RoutedCommand.SendSms).contactName)
        assertNull(routed.phoneNumber)
        assertNull(routed.messageBody)
    }

    @Test
    fun smsSendLowercaseVariant() {
        val routed = route("ayşe'ye mesaj at")
        assertEquals("ayşe", (routed as RoutedCommand.SendSms).contactName)
        assertNull(routed.messageBody)
    }

    @Test
    fun smsWithDiyeClauseBody() {
        val routed = route("Sıla'ya toplantı 5'te diye mesaj gönder")
        assertEquals("Sıla", (routed as RoutedCommand.SendSms).contactName)
        assertEquals("toplantı 5'te", routed.messageBody)
    }

    @Test
    fun smsWithQuotedBody() {
        val routed = route("anneme \"geç kaldım, görüşürüz\" diye sms at")
        assertEquals("anne", (routed as RoutedCommand.SendSms).contactName)
        assertEquals("geç kaldım, görüşürüz", routed.messageBody)
    }

    @Test
    fun smsToPhoneNumber() {
        val routed = route("0532 123 45 67 numarasına sms gönder")
        val sms = routed as RoutedCommand.SendSms
        assertNull(sms.contactName)
        assertEquals("05321234567", sms.phoneNumber)
        assertNull(sms.messageBody)
    }

    @Test
    fun smsToPhoneNumberWithBody() {
        val routed = route("0532 123 45 67 numarasına görüşürüz diye mesaj yolla")
        val sms = routed as RoutedCommand.SendSms
        assertEquals("05321234567", sms.phoneNumber)
        assertEquals("görüşürüz", sms.messageBody)
    }

    // ---- Calls --------------------------------------------------------------

    @Test
    fun callContactWithApostrophe() {
        val routed = route("Sıla'yı ara")
        assertEquals("Sıla", (routed as RoutedCommand.MakeCall).contactName)
        assertNull(routed.phoneNumber)
    }

    @Test
    fun callContactWithoutApostrophe() {
        val routed = route("annemi ara")
        assertEquals("anne", (routed as RoutedCommand.MakeCall).contactName)
    }

    @Test
    fun callPhoneNumber() {
        val routed = route("0532 123 45 67 numarasını ara")
        val call = routed as RoutedCommand.MakeCall
        assertEquals("05321234567", call.phoneNumber)
        assertNull(call.contactName)
    }

    // ---- App launch ---------------------------------------------------------

    @Test
    fun openAppWithApostropheSuffix() {
        val routed = route("YouTube'u aç")
        assertEquals("YouTube", (routed as RoutedCommand.OpenApp).appName)
    }

    @Test
    fun openAppWithApplicationQualifier() {
        val routed = route("kamera uygulamasını aç")
        assertEquals("kamera", (routed as RoutedCommand.OpenApp).appName)
    }

    @Test
    fun openAppPlainName() {
        // The trailing accusative "i" is consumed by the pattern; the fuzzy
        // app-label match still resolves "Ayarlar" exactly.
        val routed = route("ayarlari aç")
        assertEquals("ayarlar", (routed as RoutedCommand.OpenApp).appName)
    }

    // ---- WhatsApp -----------------------------------------------------------

    @Test
    fun whatsappWithBodyAfterRecipient() {
        val routed = route("whatsapp'ta Sıla'ya merhaba gönder")
        val wa = routed as RoutedCommand.WhatsAppMessage
        assertEquals("Sıla", wa.contactName)
        assertEquals("merhaba", wa.messageBody)
    }

    @Test
    fun whatsappWithoutBody() {
        val routed = route("Sıla'ya whatsapp mesajı gönder")
        val wa = routed as RoutedCommand.WhatsAppMessage
        assertEquals("Sıla", wa.contactName)
        assertNull(wa.messageBody)
    }

    // ---- Non-actions (must fall back to the LLM/chat flow) -------------------

    @Test
    fun ordinaryChatIsNotRouted() {
        assertNull(route("bugün hava nasıl"))
        assertNull(route("Jarvis kimsin"))
        assertNull(route("yarın erken kalkmam gerek"))
    }

    @Test
    fun smsWithoutRecipientIsNotRouted() {
        assertNull(route("sms gönder"))
    }

    @Test
    fun commandTooShortIsNotRouted() {
        assertNull(route("ara?"))
        assertNull(route("a"))
    }

    // ---- Suffix handling ------------------------------------------------------

    @Test
    fun apostropheSuffixIsStripped() {
        assertEquals("Sıla", TurkishCommandRouter.stripCaseSuffix("Sıla'ya"))
        assertEquals("Sıla", TurkishCommandRouter.stripCaseSuffix("Sıla’yı"))
    }

    @Test
    fun possessiveDativeIsStripped() {
        assertEquals("anne", TurkishCommandRouter.stripCaseSuffix("anneme"))
        assertEquals("anne", TurkishCommandRouter.stripCaseSuffix("annemi"))
        assertEquals("baba", TurkishCommandRouter.stripCaseSuffix("babamı"))
    }

    @Test
    fun plainNameIsKept() {
        assertEquals("Sıla", TurkishCommandRouter.stripCaseSuffix("Sıla"))
    }
}
