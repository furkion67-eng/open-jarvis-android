package com.openjarvis.commands

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Issue #5: a pending sensitive action (SMS send / call / WhatsApp) is resolved
 * by spoken confirm/cancel answers. The parser must never guess for utterances
 * that are not unambiguous confirmations or cancellations.
 */
class VoiceDecisionTest {

    // ---- Confirm -----------------------------------------------------------

    @Test
    fun plainEvetConfirms() {
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("evet"))
    }

    @Test
    fun confirmIgnoresCaseAndPunctuation() {
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("Evet."))
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("Onayla!"))
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("TAMAM"))
    }

    @Test
    fun asciiTranscriptionVariantsConfirm() {
        // STT engines may drop Turkish diacritics ("hayır" → "hayir").
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("gonder"))
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("onayliyorum"))
    }

    @Test
    fun twoWordConfirmPhrases() {
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("evet, gönder"))
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("evet ara"))
    }

    // ---- Cancel ------------------------------------------------------------

    @Test
    fun plainHayirCancels() {
        assertEquals(VoiceDecision.Decision.Cancel, VoiceDecision.parse("hayır"))
    }

    @Test
    fun cancelVariants() {
        assertEquals(VoiceDecision.Decision.Cancel, VoiceDecision.parse("İptal et"))
        assertEquals(VoiceDecision.Decision.Cancel, VoiceDecision.parse("vazgeç"))
        assertEquals(VoiceDecision.Decision.Cancel, VoiceDecision.parse("gönderme"))
        assertEquals(VoiceDecision.Decision.Cancel, VoiceDecision.parse("hayir"))
    }

    @Test
    fun cancelIsNotSubstringConfusedWithConfirm() {
        // "gönderme" (don't send) contains "gönder"; exact-phrase matching must
        // keep them strictly separate.
        assertEquals(VoiceDecision.Decision.Cancel, VoiceDecision.parse("gönderme"))
        assertEquals(VoiceDecision.Decision.Confirm, VoiceDecision.parse("gönder"))
    }

    // ---- None (fall back to normal flow) ------------------------------------

    @Test
    fun freeTextIsNotADecision() {
        assertEquals(VoiceDecision.Decision.None, VoiceDecision.parse("geç kaldım, yoldayım"))
        assertEquals(VoiceDecision.Decision.None, VoiceDecision.parse("belki sonra"))
    }

    @Test
    fun commandsThatAreNotAnswersAreNone() {
        // A new command utterance must keep flowing to the normal router.
        assertEquals(VoiceDecision.Decision.None, VoiceDecision.parse("Sıla'ya sms gönder"))
        assertEquals(VoiceDecision.Decision.None, VoiceDecision.parse("youtube'u aç"))
    }

    @Test
    fun emptyAndPunctuationOnlyAreNone() {
        assertEquals(VoiceDecision.Decision.None, VoiceDecision.parse(""))
        assertEquals(VoiceDecision.Decision.None, VoiceDecision.parse("   "))
        assertEquals(VoiceDecision.Decision.None, VoiceDecision.parse("..."))
    }
}
