package com.openjarvis.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AssistantServiceStateMachineTest {

    @Test
    fun startRequestedTransitionsNotRunningToStarting() {
        assertEquals(
            AssistantServiceState.Starting,
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.NotRunning,
                AssistantServiceEvent.StartRequested
            )
        )
    }

    @Test
    fun serviceReadyTransitionsStartingToListening() {
        assertEquals(
            AssistantServiceState.Listening,
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.Starting,
                AssistantServiceEvent.ServiceReady
            )
        )
    }

    @Test
    fun serviceReadyIsIgnoredOutsideStarting() {
        assertEquals(
            AssistantServiceState.NotRunning,
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.NotRunning,
                AssistantServiceEvent.ServiceReady
            )
        )
    }

    @Test
    fun startRequestedWhileListeningKeepsListening() {
        assertEquals(
            AssistantServiceState.Listening,
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.Listening,
                AssistantServiceEvent.StartRequested
            )
        )
    }

    @Test
    fun wakeWordWithCommandDispatchesCommand() {
        assertEquals(
            AssistantServiceState.CommandDispatched("whatsapp aç"),
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.Listening,
                AssistantServiceEvent.WakeWordHeard("whatsapp aç")
            )
        )
    }

    @Test
    fun wakeWordWithoutCommandMovesToAwaitingCommand() {
        val next = AssistantServiceStateMachine.reduce(
            AssistantServiceState.Listening,
            AssistantServiceEvent.WakeWordHeard("")
        )
        assertTrue(next is AssistantServiceState.AwaitingCommand)
        assertTrue((next as AssistantServiceState.AwaitingCommand).prompt.contains("Komutunuzu söyleyin"))
    }

    @Test
    fun commandDispatchedReturnsToListening() {
        assertEquals(
            AssistantServiceState.Listening,
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.CommandDispatched("whatsapp aç"),
                AssistantServiceEvent.CommandDispatched("whatsapp aç")
            )
        )
    }

    @Test
    fun failureProducesErrorState() {
        assertEquals(
            AssistantServiceState.Error("Mikrofon izni verilmedi"),
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.Starting,
                AssistantServiceEvent.Failed("Mikrofon izni verilmedi")
            )
        )
    }

    @Test
    fun batteryPauseProducesPausedState() {
        val next = AssistantServiceStateMachine.reduce(
            AssistantServiceState.Listening,
            AssistantServiceEvent.PausedForBattery("Pil seviyesi düşük")
        )
        assertTrue(next is AssistantServiceState.Paused)
    }

    @Test
    fun stoppedByUserAndDestroyProduceNotRunning() {
        assertEquals(
            AssistantServiceState.NotRunning,
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.Listening,
                AssistantServiceEvent.StoppedByUser
            )
        )
        assertEquals(
            AssistantServiceState.NotRunning,
            AssistantServiceStateMachine.reduce(
                AssistantServiceState.CommandDispatched("a"),
                AssistantServiceEvent.ServiceDestroyed
            )
        )
    }

    @Test
    fun isServiceActiveCoversRunningStatesOnly() {
        assertTrue(AssistantServiceStateMachine.isServiceActive(AssistantServiceState.Starting))
        assertTrue(AssistantServiceStateMachine.isServiceActive(AssistantServiceState.Listening))
        assertTrue(
            AssistantServiceStateMachine.isServiceActive(
                AssistantServiceState.AwaitingCommand("komut")
            )
        )
        assertTrue(
            AssistantServiceStateMachine.isServiceActive(
                AssistantServiceState.CommandDispatched("a")
            )
        )
        assertFalse(AssistantServiceStateMachine.isServiceActive(AssistantServiceState.NotRunning))
        assertFalse(
            AssistantServiceStateMachine.isServiceActive(AssistantServiceState.Paused("pil"))
        )
        assertFalse(
            AssistantServiceStateMachine.isServiceActive(AssistantServiceState.Error("hata"))
        )
    }

    @Test
    fun resolveUtteranceOutsideAwaitingStateRequiresWakeWord() {
        assertEquals(
            UtteranceResolution.DispatchCommand("whatsapp aç"),
            AssistantServiceStateMachine.resolveUtterance(AssistantServiceState.Listening, "Jarvis whatsapp aç")
        )
        assertEquals(
            UtteranceResolution.WaitForCommand,
            AssistantServiceStateMachine.resolveUtterance(AssistantServiceState.Listening, "jarvis")
        )
        assertEquals(
            UtteranceResolution.Ignore,
            AssistantServiceStateMachine.resolveUtterance(AssistantServiceState.Listening, "hava nasıl")
        )
    }

    @Test
    fun resolveUtteranceInAwaitingStateTreatsNextSpeechAsCommand() {
        assertEquals(
            UtteranceResolution.DispatchCommand("Sıla'ya SMS gönder"),
            AssistantServiceStateMachine.resolveUtterance(
                AssistantServiceState.AwaitingCommand("komut"),
                "Sıla'ya SMS gönder"
            )
        )
        assertEquals(
            UtteranceResolution.Ignore,
            AssistantServiceStateMachine.resolveUtterance(
                AssistantServiceState.AwaitingCommand("komut"),
                "  "
            )
        )
    }

    @Test
    fun statusTextCoversAllStatesInTurkish() {
        val texts = listOf(
            AssistantServiceState.NotRunning,
            AssistantServiceState.Starting,
            AssistantServiceState.Listening,
            AssistantServiceState.AwaitingCommand("komut"),
            AssistantServiceState.CommandDispatched("a"),
            AssistantServiceState.Paused("pil"),
            AssistantServiceState.Error("hata")
        ).map { AssistantServiceStateMachine.statusText(it) }
        assertTrue(texts.all { it.isNotBlank() })
        assertTrue(texts[2].contains("dinliyor"))
        assertTrue(texts[5] == "pil")
    }
}
