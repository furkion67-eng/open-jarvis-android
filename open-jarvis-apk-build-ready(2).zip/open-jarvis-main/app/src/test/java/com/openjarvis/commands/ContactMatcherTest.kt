package com.openjarvis.commands

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContactMatcherTest {

    @Test
    fun turkishCaseAndDiacriticsAreNormalized() {
        assertEquals("sila", ContactMatcher.normalize("Sıla"))
        assertEquals("sila", ContactMatcher.normalize("SILA"))
        assertEquals("kisi", ContactMatcher.normalize("Kişi"))
    }

    @Test
    fun exactMatchScoresHighest() {
        assertEquals(100, ContactMatcher.score("sıla", "Sıla"))
        assertEquals(80, ContactMatcher.score("ayse", "Ayşe Yılmaz"))
        // "Anne" does not contain "annem"; the levenshtein fallback (distance 1) scores 50.
        assertEquals(50, ContactMatcher.score("annem", "Anne"))
        assertEquals(80, ContactMatcher.score("ayse yilmaz", "Ayşe Yılmaz Kaya"))
    }

    @Test
    fun bestMatchFindsExactContact() {
        val match = ContactMatcher.bestMatch(
            "sıla",
            listOf("Sıla Demir" to "+905321112233", "Ayşe Kaya" to "+905324445566")
        )
        assertTrue(match is ContactMatcher.BestMatch.Exact)
        assertEquals("+905321112233", (match as ContactMatcher.BestMatch.Exact).match.value)
    }

    @Test
    fun bestMatchRefusesAmbiguousContacts() {
        val match = ContactMatcher.bestMatch(
            "ayşe",
            listOf("Ayşe Yılmaz" to "+905321111111", "Ayşe Kaya" to "+905322222222")
        )
        assertTrue(match is ContactMatcher.BestMatch.Ambiguous)
    }

    @Test
    fun bestMatchNotFound() {
        val match = ContactMatcher.bestMatch(
            "zekeriya",
            listOf("Sıla Demir" to "+905321112233")
        )
        assertTrue(match is ContactMatcher.BestMatch.NotFound)
    }

    @Test
    fun identicalContactsWithDifferentNumbersResolveExactly() {
        val match = ContactMatcher.bestMatch(
            "sıla",
            listOf("Sıla" to "+905321111111", "Sıla" to "+905322222222")
        )
        assertTrue(match is ContactMatcher.BestMatch.Exact)
    }

    @Test
    fun appLabelsMatchFuzzily() {
        val match = ContactMatcher.bestMatch(
            "youtube",
            listOf("YouTube" to "com.google.android.youtube", "Google News" to "com.google.android.apps.news")
        )
        assertTrue(match is ContactMatcher.BestMatch.Exact)
        assertEquals("com.google.android.youtube", (match as ContactMatcher.BestMatch.Exact).match.value)
    }
}
