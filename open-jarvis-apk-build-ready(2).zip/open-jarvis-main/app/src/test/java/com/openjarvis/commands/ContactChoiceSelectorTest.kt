package com.openjarvis.commands

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure-JVM tests for spoken disambiguation of ambiguous contacts (issue #5).
 * Two identically named contacts must never become a dead end.
 */
class ContactChoiceSelectorTest {

    private val candidates = listOf(
        ContactMatcher.Match("Sıla Yılmaz", "05051112233", 80),
        ContactMatcher.Match("Sıla Demir", "05334445566", 80)
    )

    @Test
    fun ordinalWordBirinciSelectsFirstCandidate() {
        val result = ContactChoiceSelector.select("birinci", candidates)
        assertTrue(result is ContactChoiceSelector.Result.Selected)
        assertEquals("Sıla Yılmaz", (result as ContactChoiceSelector.Result.Selected).match.label)
    }

    @Test
    fun ordinalNumberIkiSelectsSecondCandidate() {
        val result = ContactChoiceSelector.select("iki", candidates)
        assertEquals("Sıla Demir", (result as ContactChoiceSelector.Result.Selected).match.label)
    }

    @Test
    fun spokenDigitSelectsCandidateByListPosition() {
        val result = ContactChoiceSelector.select("2", candidates)
        assertEquals("Sıla Demir", (result as ContactChoiceSelector.Result.Selected).match.label)
    }

    @Test
    fun outOfRangeNumberIsUnmatched() {
        val result = ContactChoiceSelector.select("9", candidates)
        assertTrue(result is ContactChoiceSelector.Result.Unmatched)
    }

    @Test
    fun fullerSpokenNameSelectsTheRightCandidate() {
        val result = ContactChoiceSelector.select("Sıla Demir", candidates)
        assertEquals("Sıla Demir", (result as ContactChoiceSelector.Result.Selected).match.label)
    }

    @Test
    fun partialNameStillSelectsViaContainsMatch() {
        val result = ContactChoiceSelector.select("demir", candidates)
        assertEquals("Sıla Demir", (result as ContactChoiceSelector.Result.Selected).match.label)
    }

    @Test
    fun phoneDigitsSpokenBackSelectTheCandidate() {
        val result = ContactChoiceSelector.select("533 444 55 66", candidates)
        assertEquals("Sıla Demir", (result as ContactChoiceSelector.Result.Selected).match.label)
    }

    @Test
    fun unrelatedTextIsUnmatchedNotGuessed() {
        val result = ContactChoiceSelector.select("hava nasıl bugün", candidates)
        assertTrue(result is ContactChoiceSelector.Result.Unmatched)
    }

    @Test
    fun emptyUtteranceIsUnmatched() {
        val result = ContactChoiceSelector.select("", candidates)
        assertTrue(result is ContactChoiceSelector.Result.Unmatched)
    }

    @Test
    fun emptyCandidateListIsUnmatched() {
        val result = ContactChoiceSelector.select("birinci", emptyList())
        assertTrue(result is ContactChoiceSelector.Result.Unmatched)
    }

    @Test
    fun fiveCandidatesSupportAllOrdinalPositions() {
        val five = listOf(
            ContactMatcher.Match("A A", "1", 80),
            ContactMatcher.Match("B B", "2", 80),
            ContactMatcher.Match("C C", "3", 80),
            ContactMatcher.Match("D D", "4", 80),
            ContactMatcher.Match("E E", "5", 80)
        )
        val answers = listOf("bir", "ikinci", "üçüncü", "dört", "beşinci")
        answers.forEachIndexed { i, answer ->
            val result = ContactChoiceSelector.select(answer, five)
            assertEquals(i, (result as ContactChoiceSelector.Result.Selected).index)
        }
    }
}
